"""Frozen reference-model external evaluation and participant-level bootstrap."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import (
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
)

from voxneuro.features.schema import (
    FEATURE_NAMES,
    SCHEMA_VERSION,
    configuration_fingerprint,
    feature_config_fingerprint,
    schema_fingerprint,
)
from voxneuro.modeling.domain_assessment import (
    MetricSummary,
    QualityAttritionSummary,
)
from voxneuro.modeling.model_bundle import load_bundle

PROJECT_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_MODEL_PATH = PROJECT_ROOT / "artifacts" / "models" / "uams_logistic_research.joblib"
FROZEN_REFERENCE_MODEL_SHA256 = "eaa271934410f72d6e4130c66aba086d24055f532b360a02425e4a4bf8ef9333"


def load_frozen_reference_model(path: Path | None = None) -> dict[str, Any]:
    """Load and cryptographically verify the frozen reference research model bundle."""
    bundle_path = path or DEFAULT_MODEL_PATH
    if not bundle_path.is_file():
        raise FileNotFoundError(f"Frozen reference model not found: {bundle_path}")

    actual_hash = hashlib.sha256(bundle_path.read_bytes()).hexdigest()
    if path is None and actual_hash != FROZEN_REFERENCE_MODEL_SHA256:
        raise ValueError(
            f"Frozen reference model checksum mismatch: "
            f"{actual_hash} != {FROZEN_REFERENCE_MODEL_SHA256}"
        )

    bundle = load_bundle(bundle_path)

    # Validate essential safety and schema metadata
    if bundle.get("feature_schema_version") != SCHEMA_VERSION:
        raise ValueError(
            f"Frozen model feature schema version mismatch: "
            f"{bundle.get('feature_schema_version')} != {SCHEMA_VERSION}"
        )

    if bundle.get("feature_schema_fingerprint") != schema_fingerprint():
        raise ValueError("Frozen model feature schema fingerprint does not match canonical Core39.")

    feat_cfg = bundle.get("feature_config")
    if not isinstance(feat_cfg, dict) or bundle.get(
        "feature_config_fingerprint"
    ) != feature_config_fingerprint(feat_cfg):
        raise ValueError("Frozen model feature configuration fingerprint is inconsistent.")

    prep_cfg = bundle.get("preprocessing_config")
    if not isinstance(prep_cfg, dict) or bundle.get(
        "preprocessing_config_fingerprint"
    ) != configuration_fingerprint(prep_cfg):
        raise ValueError("Frozen model preprocessing configuration fingerprint is inconsistent.")

    if bundle.get("allow_user_microphone_inference") is not False:
        raise ValueError("Frozen model must enforce allow_user_microphone_inference: false.")

    return bundle


def _compute_metrics_from_arrays(
    y_true: np.ndarray, y_pred: np.ndarray, y_score: np.ndarray | None = None
) -> dict[str, float]:
    """Compute standard classification metrics for binary 0/1 vectors."""
    bacc = float(balanced_accuracy_score(y_true, y_pred))
    sens = float(recall_score(y_true, y_pred, zero_division=0))
    # Specificity = recall of negative class
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    spec = float(tn / (tn + fp)) if (tn + fp) > 0 else 0.0
    prec = float(precision_score(y_true, y_pred, zero_division=0))
    f1 = float(f1_score(y_true, y_pred, zero_division=0))
    mcc = float(matthews_corrcoef(y_true, y_pred))

    roc_auc = float("nan")
    ap = float("nan")
    if y_score is not None and len(np.unique(y_true)) > 1:
        try:
            roc_auc = float(roc_auc_score(y_true, y_score))
            ap = float(average_precision_score(y_true, y_score))
        except Exception:
            pass

    return {
        "balanced_accuracy": bacc,
        "sensitivity": sens,
        "specificity": spec,
        "precision": prec,
        "f1": f1,
        "roc_auc": roc_auc,
        "average_precision": ap,
        "mcc": mcc,
    }


def evaluate_frozen_model_on_cohort(
    bundle: dict[str, Any],
    features_df: pd.DataFrame,
    participant_col: str = "participant_id",
    target_col: str = "diagnostic_group",
    random_seed: int = 2026,
    n_bootstrap: int = 1000,
    min_subgroup_n: int = 10,
) -> dict[str, MetricSummary]:
    """Evaluate frozen model with participant-level aggregation and bootstrap uncertainty."""
    if features_df.empty:
        raise ValueError("Features DataFrame cannot be empty for cohort evaluation.")

    required_cols = {participant_col, target_col} | set(FEATURE_NAMES)
    missing = required_cols - set(features_df.columns)
    if missing:
        raise ValueError(f"Cohort evaluation DataFrame missing columns: {sorted(missing)}")

    # Aggregate to participant-level (averaging numeric features per participant)
    grouped = features_df.groupby([participant_col, target_col])[FEATURE_NAMES].mean().reset_index()

    participants = grouped[participant_col].values
    y_raw = grouped[target_col].values

    # Map labels to 0 (HC) and 1 (PD)
    y_true = np.array(
        [1 if str(v).lower() in {"pd", "1", "parkinson", "parkinsons"} else 0 for v in y_raw]
    )

    n_total = len(participants)
    n_pd = int(np.sum(y_true == 1))
    n_hc = int(np.sum(y_true == 0))

    # Safety: check sample size
    is_small_sample = (n_total < 20) or (n_pd < min_subgroup_n) or (n_hc < min_subgroup_n)

    X = grouped[FEATURE_NAMES]
    model = bundle["model"]
    y_pred = model.predict(X)

    y_score = None
    if hasattr(model, "predict_proba"):
        try:
            proba = model.predict_proba(X)
            if proba.shape[1] > 1:
                y_score = proba[:, 1]
            else:
                y_score = proba[:, 0]
        except Exception:
            y_score = None
    elif hasattr(model, "decision_function"):
        try:
            y_score = model.decision_function(X)
        except Exception:
            y_score = None

    point_metrics = _compute_metrics_from_arrays(y_true, y_pred, y_score)

    if is_small_sample:
        # Small sample flag: confidence intervals are unreliable
        return {
            k: MetricSummary(
                point_estimate=v if np.isfinite(v) else None,
                ci_lower=None,
                ci_upper=None,
                status="UNRELIABLE_SMALL_SAMPLE",
            )
            for k, v in point_metrics.items()
        }

    # Stratified participant-level bootstrap
    rng = np.random.default_rng(random_seed)
    pd_indices = np.where(y_true == 1)[0]
    hc_indices = np.where(y_true == 0)[0]

    boot_results: dict[str, list[float]] = {k: [] for k in point_metrics}

    for _ in range(n_bootstrap):
        sample_pd = rng.choice(pd_indices, size=len(pd_indices), replace=True)
        sample_hc = rng.choice(hc_indices, size=len(hc_indices), replace=True)
        sample_idx = np.concatenate([sample_pd, sample_hc])

        y_boot_true = y_true[sample_idx]
        y_boot_pred = y_pred[sample_idx]
        y_boot_score = y_score[sample_idx] if y_score is not None else None

        iter_metrics = _compute_metrics_from_arrays(y_boot_true, y_boot_pred, y_boot_score)
        for k, v in iter_metrics.items():
            if np.isfinite(v):
                boot_results[k].append(v)

    summaries: dict[str, MetricSummary] = {}
    for k, pt in point_metrics.items():
        vals = boot_results[k]
        if len(vals) >= 100:
            ci_l = float(np.percentile(vals, 2.5))
            ci_u = float(np.percentile(vals, 97.5))
            summaries[k] = MetricSummary(
                point_estimate=pt if np.isfinite(pt) else None,
                ci_lower=ci_l,
                ci_upper=ci_u,
                status="ESTIMATED",
            )
        else:
            summaries[k] = MetricSummary(
                point_estimate=pt if np.isfinite(pt) else None,
                ci_lower=None,
                ci_upper=None,
                status="NOT_ESTIMABLE",
            )

    return summaries


def build_quality_attrition_summary(
    total_enrolled: int,
    recordings_attempted: int,
    passed_count: int,
    reasons: dict[str, int] | None = None,
    failures_by_group: dict[str, int] | None = None,
) -> QualityAttritionSummary:
    """Construct an auditable QualityAttritionSummary instance."""
    failed_count = recordings_attempted - passed_count
    rate = float(failed_count / recordings_attempted) if recordings_attempted > 0 else 0.0

    return QualityAttritionSummary(
        total_enrolled=total_enrolled,
        recordings_attempted=recordings_attempted,
        recordings_passed_quality=passed_count,
        attrition_rate=rate,
        reasons=dict(reasons or {}),
        failures_by_group=dict(failures_by_group or {}),
    )
