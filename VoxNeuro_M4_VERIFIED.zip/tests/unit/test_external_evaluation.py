"""Unit tests for frozen reference model evaluation, bootstrap, and suppression."""

import numpy as np
import pandas as pd
import pytest
from sklearn.dummy import DummyClassifier

from voxneuro.config import load_config
from voxneuro.features.schema import FEATURE_NAMES
from voxneuro.modeling.domain_evaluation import (
    DEFAULT_MODEL_PATH,
    build_quality_attrition_summary,
    evaluate_frozen_model_on_cohort,
    load_frozen_reference_model,
)
from voxneuro.modeling.model_bundle import make_bundle


def _get_test_bundle():
    if DEFAULT_MODEL_PATH.is_file():
        return load_frozen_reference_model()
    X = pd.DataFrame(np.zeros((2, len(FEATURE_NAMES))), columns=FEATURE_NAMES)
    model = DummyClassifier(strategy="constant", constant=0).fit(X, [0, 1])
    feat_cfg = load_config("feature_config.yaml")
    prep_cfg = load_config("audio_config.yaml")
    return make_bundle(
        model=model,
        dataset_provenance="clean-room test",
        dataset_version="test-v1",
        dataset_checksum_sha256="a" * 64,
        code_version="b" * 64,
        training_evaluation_receipt_sha256="c" * 64,
        validation_method="clean-room test only",
        software_versions={"python": "3.12"},
        feature_config=feat_cfg,
        preprocessing_config=prep_cfg,
    )


def test_load_frozen_reference_model():
    if not DEFAULT_MODEL_PATH.is_file():
        with pytest.raises(FileNotFoundError, match="Frozen reference model not found"):
            load_frozen_reference_model()
        return

    bundle = load_frozen_reference_model()
    assert bundle["feature_schema_version"] == "voxneuro.voice.v3"
    assert bundle["domain_compatibility_verified"] is False
    assert bundle["allow_user_microphone_inference"] is False
    assert hasattr(bundle["model"], "predict")


def test_evaluate_frozen_model_bootstrap():
    bundle = _get_test_bundle()
    rng = np.random.default_rng(2026)

    # Cohort of 30 participants (15 PD, 15 HC)
    n = 30
    data = {name: rng.normal(0, 1, n) for name in FEATURE_NAMES}
    data["participant_id"] = [f"P_{i:03d}" for i in range(n)]
    data["diagnostic_group"] = ["PD"] * 15 + ["HC"] * 15
    df = pd.DataFrame(data)

    metrics = evaluate_frozen_model_on_cohort(bundle, df, n_bootstrap=100)
    assert "balanced_accuracy" in metrics
    assert "sensitivity" in metrics
    assert "specificity" in metrics

    bacc = metrics["balanced_accuracy"]
    assert bacc.status == "ESTIMATED"
    assert bacc.point_estimate is not None
    assert bacc.ci_lower is not None
    assert bacc.ci_upper is not None
    assert 0.0 <= bacc.ci_lower <= bacc.ci_upper <= 1.0


def test_small_cell_suppression_on_small_cohort():
    """Small cohort (e.g. N < 20 or group < 10) must flag UNRELIABLE_SMALL_SAMPLE."""
    bundle = _get_test_bundle()
    rng = np.random.default_rng(2026)

    # Only 8 participants
    n = 8
    data = {name: rng.normal(0, 1, n) for name in FEATURE_NAMES}
    data["participant_id"] = [f"P_{i:03d}" for i in range(n)]
    data["diagnostic_group"] = ["PD"] * 4 + ["HC"] * 4
    df = pd.DataFrame(data)

    metrics = evaluate_frozen_model_on_cohort(bundle, df)
    bacc = metrics["balanced_accuracy"]
    assert bacc.status == "UNRELIABLE_SMALL_SAMPLE"
    assert bacc.ci_lower is None
    assert bacc.ci_upper is None


def test_build_quality_attrition_summary():
    qa = build_quality_attrition_summary(
        total_enrolled=50,
        recordings_attempted=48,
        passed_count=40,
        reasons={"clipping": 5, "low_rms": 3},
        failures_by_group={"PD": 5, "HC": 3},
    )
    assert qa.total_enrolled == 50
    assert qa.recordings_attempted == 48
    assert qa.recordings_passed_quality == 40
    assert abs(qa.attrition_rate - (8 / 48)) < 1e-5
    assert qa.reasons["clipping"] == 5
