"""Evaluate candidate external recording domain against the frozen reference model."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd

from voxneuro.modeling.domain_evaluation import (
    evaluate_frozen_model_on_cohort,
    load_frozen_reference_model,
)
from voxneuro.modeling.domain_registry import load_domain_registry
from voxneuro.modeling.domain_shift import (
    compare_acquisition_metadata,
    compute_feature_shift,
    summarize_domain_shift,
)

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--domain", default="neurovoz_studio", help="Candidate domain identifier")
    parser.add_argument(
        "--features-path", type=Path, default=None, help="Path to extracted features CSV"
    )
    parser.add_argument(
        "--out-dir", type=Path, default=ROOT / "artifacts" / "reports" / "domain_validation"
    )
    parser.add_argument("--json", action="store_true", help="Print summary as JSON")
    args = parser.parse_args()

    registry = load_domain_registry()
    if not registry.is_registered(args.domain):
        print(f"Error: Unknown domain {args.domain!r}")
        return 1

    entry = registry.get_domain(args.domain)
    ref_entry = registry.get_domain("uams_telephone")
    args.out_dir.mkdir(parents=True, exist_ok=True)

    acq_diffs = compare_acquisition_metadata(ref_entry.metadata.to_dict(), entry.metadata.to_dict())

    if args.features_path is None or not args.features_path.is_file():
        summary = {
            "domain_id": entry.domain_id,
            "status": "FRAMEWORK_VERIFIED_DOMAIN_VALIDATION_PENDING",
            "decision_rationale": (
                f"Candidate domain {entry.domain_id!r} evaluation framework verified. "
                "Independent raw audio or extracted features are not present in "
                "the local workspace. "
                "Validation is pending execution of a licensed Data Use Agreement."
            ),
            "acquisition_differences": acq_diffs,
            "inference_eligible": False,
        }
        report_file = args.out_dir / f"{entry.domain_id}_evaluation_status.json"
        report_file.write_text(json.dumps(summary, indent=2), encoding="utf-8")

        if args.json:
            print(json.dumps(summary, indent=2))
        else:
            print(f"=== Domain Evaluation Status: {entry.domain_id} ===")
            print(f"Status: {summary['status']}")
            print(f"Rationale: {summary['decision_rationale']}")
            print(f"Report written to: {report_file}")
        return 0

    # If features are supplied:
    bundle = load_frozen_reference_model()
    features_df = pd.read_csv(args.features_path)
    metrics = evaluate_frozen_model_on_cohort(bundle, features_df)

    # Shift against UAMS reference if UAMS processed table exists
    uams_path = ROOT / "data" / "processed" / "voice_features.csv"
    shift_summary = None
    if uams_path.is_file():
        uams_df = pd.read_csv(uams_path)
        shift_df = compute_feature_shift(uams_df, features_df)
        shift_csv = args.out_dir / f"{entry.domain_id}_feature_shift.csv"
        shift_df.to_csv(shift_csv, index=False)
        shift_summary = summarize_domain_shift(shift_df, acq_diffs).to_dict()

    eval_summary = {
        "domain_id": entry.domain_id,
        "status": "CANDIDATE_DOMAIN_EVALUATED_PENDING_REVIEW",
        "performance_metrics": {k: v.to_dict() for k, v in metrics.items()},
        "domain_shift_summary": shift_summary,
        "inference_eligible": False,
    }
    report_file = args.out_dir / f"{entry.domain_id}_evaluation_results.json"
    report_file.write_text(json.dumps(eval_summary, indent=2), encoding="utf-8")

    if args.json:
        print(json.dumps(eval_summary, indent=2))
    else:
        print(f"=== Domain Evaluation Completed: {entry.domain_id} ===")
        print(f"Status: {eval_summary['status']}")
        for k, v in metrics.items():
            print(f"- {k}: {v.point_estimate} (status: {v.status})")
        print(f"Report written to: {report_file}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
