"""Approachable public and participant digital-health pages for VoxNeuro M6."""

from __future__ import annotations

import html
import json
import sqlite3
from collections.abc import Callable
from typing import Any

import pandas as pd
import streamlit as st

from voxneuro.modeling.prediction_service import (
    PredictionResult,
    run_prediction_service,
)
from voxneuro.study.auth import (
    AuthorizationError,
    UserAccount,
    authenticate_user,
    complete_password_reset,
    issue_password_reset_token,
    register_user,
    revoke_session,
    update_user_profile_preferences,
)
from voxneuro.study.consent import get_active_consent_for_participant, record_consent
from voxneuro.study.participant import get_participant, register_participant
from voxneuro.study.registry import get_study, list_studies
from voxneuro.ui.theme import (
    render_medical_disclaimer,
    render_plain_quality_summary,
    render_prediction_outcome_card,
)

WIZARD_STEPS = [
    "Overview",
    "Consent",
    "Room & Mic Prep",
    "Voice Sample",
    "Quality Check",
    "Results",
]


def show_consumer_home(on_start_assessment: Callable[[], None]) -> None:
    """Landing and Overview experience for ordinary users with Hero CTA at button[0]."""
    st.title("VoxNeuro")
    st.markdown(
        '<div class="vx-hero-card">'
        '<div class="vx-hero-eyebrow">Calm · Guided Voice Research Platform</div>'
        "<h2 style='margin:0 0 0.65rem 0;'>Check how your voice measures in under 30 seconds</h2>"
        "<p style='font-size:1.05rem; color:#4C515A; max-width:740px; margin:0 0 0.9rem 0;'>"
        "Record a comfortable sustained vowel sound (&ldquo;ah&rdquo;) in a quiet room. "
        "VoxNeuro checks recording clarity, summarizes gentle voice stability measures, and "
        "keeps everything private under your control."
        "</p>"
        "<div style='display:flex; flex-wrap:wrap; gap:0.5rem; margin-top:0.5rem;'>"
        '<span class="vx-pill-badge">Not Stored By Default</span>'
        '<span class="vx-pill-badge">Plain-Language Summary</span>'
        '<span class="vx-pill-badge">Research Tool · Non-Diagnostic</span>'
        "</div>"
        "</div>",
        unsafe_allow_html=True,
    )
    st.button(
        "Start voice check",
        type="primary",
        on_click=on_start_assessment,
        key="m6_hero_start_cta",
    )

    render_medical_disclaimer()

    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown(
            '<div class="vx-card"><h4>1. Quiet space &amp; consent</h4>'
            "<p>Review clear information on how your recording is used before analysis. "
            "Your voice audio stays in temporary memory only.</p></div>",
            unsafe_allow_html=True,
        )
    with col2:
        st.markdown(
            '<div class="vx-card"><h4>2. One steady breath</h4>'
            "<p>Hold a relaxed &ldquo;ah&rdquo; sound for 3 to 5 seconds using your device "
            "microphone or upload an existing clear WAV clip.</p></div>",
            unsafe_allow_html=True,
        )
    with col3:
        st.markdown(
            '<div class="vx-card"><h4>3. Honest, clear feedback</h4>'
            "<p>See immediately whether your recording passed sound quality checks and why "
            "disease classification is withheld when evidence is incomplete.</p></div>",
            unsafe_allow_html=True,
        )


def show_how_it_works() -> None:
    """Friendly visual and step-by-step explanation for first-time visitors."""
    st.title("How VoxNeuro Works")
    st.write(
        "VoxNeuro is designed so anyone can participate comfortably without needing technical "
        "knowledge of audio engineering or machine learning."
    )
    steps = [
        (
            "Step 1 · Permission First",
            "Before recording or saving optional summary metrics, you review exactly what the "
            "study does and decide whether to opt in or stay temporary-only.",
        ),
        (
            "Step 2 · Simple 3–5 Second Voice Task",
            "Sit upright in a quiet room, take an easy breath, and hold a steady 'ah' sound at a "
            "normal speaking volume.",
        ),
        (
            "Step 3 · Automatic Clarity Screening",
            "VoxNeuro checks loudness, background noise, clipping distortion, and minimum length "
            "before measuring steadiness, pitch clarity, and breathiness.",
        ),
        (
            "Step 4 · Safety-First Result or Honest Abstention",
            "When an automated research model has not been validated for your microphone type or "
            "your recording is noisy, VoxNeuro transparently abstains instead of guessing.",
        ),
    ]
    for title, body in steps:
        st.markdown(
            f'<div class="vx-card"><h4>{html.escape(title)}</h4><p>{html.escape(body)}</p></div>',
            unsafe_allow_html=True,
        )
    render_medical_disclaimer()


def show_privacy_and_safety() -> None:
    """Clear, jargon-free privacy, retention, and safety explanation."""
    st.title("Privacy & Safety")
    render_medical_disclaimer()
    c1, c2 = st.columns(2)
    with c1:
        st.markdown(
            '<div class="vx-card"><h4>Audio is Never Auto-Saved</h4>'
            "<p>Recordings are processed temporarily in memory to compute acoustic quality and "
            "summary measurements. Raw audio files are discarded automatically unless explicit "
            "study storage permission applies.</p></div>",
            unsafe_allow_html=True,
        )
    with c2:
        st.markdown(
            '<div class="vx-card"><h4>Strict Non-Diagnostic Guardrails</h4>'
            "<p>VoxNeuro refuses to generate disease probability estimates for unvalidated "
            "microphones or poor-quality recordings. You can also withdraw consent and erase "
            "stored summary records at any time.</p></div>",
            unsafe_allow_html=True,
        )
    st.markdown(
        '<div class="vx-card"><h4>Download Only What You Want</h4>'
        "<p>You can download a clean readable summary of your session directly to your device, "
        "without filenames, system paths, or medical claims attached.</p></div>",
        unsafe_allow_html=True,
    )


def show_help_faq() -> None:
    """Clear FAQ for recording problems, microphone permissions, and interpreting results."""
    st.title("Help & Frequently Asked Questions")
    faqs = [
        (
            "Why did VoxNeuro say 'No Research Classification Produced (Abstention)'?",
            "VoxNeuro only outputs automated research scores when a validated model is approved "
            "for your exact microphone domain, your recording passes sound quality checks, and "
            "features are within training bounds. Abstaining protects against unreliable guesses.",
        ),
        (
            "What makes a good voice recording?",
            "Choose a quiet room away from fans or TVs, hold the mic 15–20 cm from your mouth, "
            "and sustain an even, natural 'ah' for about 3 to 5 seconds.",
        ),
        (
            "My browser blocked microphone access—what can I do?",
            "Check the lock/microphone icon in your browser bar to allow microphone access, "
            "or switch to 'Upload WAV' to analyze a recording saved separately on your device.",
        ),
        (
            "Can I share this output with my doctor?",
            "This report provides experimental voice acoustics only and is not a medical test or "
            "diagnosis. Always speak directly with a qualified clinician about symptoms.",
        ),
    ]
    for q, a in faqs:
        with st.expander(q, expanded=True):
            st.write(a)


def show_guided_consent_step(conn: sqlite3.Connection | None, user: UserAccount | None) -> bool:
    """Render Step 2 Consent check/capture backed by real SQLite consents when signed in."""
    if user is None or conn is None:
        st.info(
            "Guest Mode (Temporary Only): Nothing from your session will be stored in the research "
            "database. Sign in from the Account tab if you are enrolled in a research study."
        )
        ack = st.checkbox(
            "I understand this is an experimental research tool and NOT a medical diagnosis.",
            value=bool(st.session_state.get("voxneuro_guest_consent_ack", False)),
            key="voxneuro_guest_consent_checkbox",
        )
        st.session_state["voxneuro_guest_consent_ack"] = ack
        return ack

    if not user.participant_id or not user.study_id:
        st.info(
            f"Signed in as {user.display_name} ({user.role}). No active longitudinal study "
            "enrollment is linked to this account; recordings remain transient."
        )
        return True

    active = get_active_consent_for_participant(conn, user.participant_id, study_id=user.study_id)
    if active:
        st.success(
            f"Active research consent on file (Form {active.consent_form_version}, recorded "
            f"{active.consent_date[:10]}). Retention opt-in: "
            f"{'Yes' if active.permission_to_retain_derived_features else 'No (transient only)'}."
        )
        return True

    st.warning("Study consent is required before saving any research session features.")
    agree = st.checkbox(
        "I voluntarily consent to sustained vowel voice recording for biomarker research.",
        key="m6_study_consent_agree",
    )
    retain_feats = st.checkbox(
        "Optional: allow saving derived acoustic features & research summaries (never raw audio).",
        value=False,
        key="m6_study_consent_retain",
    )
    if st.button("Confirm & Record Consent", key="m6_submit_consent_btn", disabled=not agree):
        try:
            # Ensure participant exists before recording consent
            try:
                get_participant(conn, user.participant_id)
            except KeyError:
                studies = list_studies(conn)
                if studies:
                    register_participant(
                        conn,
                        participant_id=user.participant_id,
                        study_id=user.study_id,
                        allowed_research_scopes=["voice_analysis", "feature_extraction"],
                    )
            if user.study_id and get_study(conn, user.study_id):
                record_consent(
                    conn,
                    participant_id=user.participant_id,
                    study_id=user.study_id,
                    consent_form_version="m6-participant-v1",
                    scope_of_permission=["voice_analysis", "feature_extraction"],
                    permitted_recording_tasks=["sustained_vowel"],
                    permitted_research_uses=["biomarker_research", "feature_extraction"],
                    permission_to_retain_derived_features=bool(retain_feats),
                    permission_to_retain_audio=False,
                    source_document_reference="ui://guided-consent-m6",
                )
                st.success("Your research consent has been saved securely.")
                st.rerun()
        except Exception as exc:
            st.error(f"Could not save consent: {exc}")
    return False


def show_plain_results_page(
    prediction: PredictionResult | None,
    features: dict[str, Any] | None,
    quality: Any | None,
    record: Any | None,
    html_report: str | None = None,
    report_dict: dict[str, Any] | None = None,
) -> None:
    """Plain-language summary page showing quality, prediction/abstention, and safe export."""
    st.title("Your Voice Check Results")
    render_medical_disclaimer()
    if prediction is None or quality is None:
        st.info("Complete a Voice Check first to view your personal summary here.")
        return

    if record is not None:
        render_plain_quality_summary(quality, record)
    render_prediction_outcome_card(prediction)

    if features:
        st.subheader("Plain-Language Voice Highlights")
        st.caption(
            "These physical acoustic properties describe your recording only; they cannot diagnose "
            "or exclude any health condition."
        )
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Speaking Pitch (F0)", f"{float(features.get('f0_mean_hz', 0.0)):.1f} Hz")
        c2.metric(
            "Pitch Steadiness (Jitter)", f"{float(features.get('jitter_local', 0.0)) * 100:.2f}%"
        )
        c3.metric("Loudness Steadiness", f"{float(features.get('shimmer_local', 0.0)) * 100:.2f}%")
        c4.metric("Voice Clarity (HNR)", f"{float(features.get('hnr_db', 0.0)):.1f} dB")

    if html_report and report_dict:
        d1, d2 = st.columns(2)
        d1.download_button(
            "Download Summary Report (HTML)",
            html_report,
            "voxneuro_summary_report.html",
            "text/html",
            key="m6_res_html_dl",
        )
        d2.download_button(
            "Download Raw Session Data (JSON)",
            json.dumps(
                {**report_dict, "prediction_summary": prediction.to_dict()},
                indent=2,
                allow_nan=False,
                default=str,
            ),
            "voxneuro_session_result.json",
            "application/json",
            key="m6_res_json_dl",
        )


def show_user_history_page(conn: sqlite3.Connection | None, user: UserAccount | None) -> None:
    """Participant-scoped history showing ONLY records belonging to the signed-in user."""
    st.title("My Assessment History")
    if user is None or conn is None:
        st.info("Please sign in from the Account page to view saved assessment records.")
        return
    if not user.prediction_retention_opt_in:
        st.info(
            "Result retention is currently OFF for your account. New voice checks run in transient "
            "memory only and are not saved to history unless you opt in on your Account page."
        )
    rows = conn.execute(
        """
        SELECT prediction_id, model_version, acquisition_domain_id, research_score,
               research_classification, calibration_status, abstained, abstention_reason, created_at
        FROM prediction_records
        WHERE user_id = ? OR (participant_id IS NOT NULL AND participant_id = ?)
        ORDER BY created_at DESC;
        """,
        (user.user_id, user.participant_id or "__none__"),
    ).fetchall()
    if not rows:
        st.info("No saved voice check summaries are stored for your account.")
        return
    df = pd.DataFrame([dict(r) for r in rows])
    st.dataframe(df, use_container_width=True)


def show_account_portal(conn: sqlite3.Connection | None) -> None:
    """Account sign-in, self-registration, password reset, and profile retention controls."""
    st.title("Account & Preferences")
    if conn is None:
        st.warning("Account storage database is not initialized yet.")
        return

    token = st.session_state.get("voxneuro_auth_token")
    current_user = st.session_state.get("voxneuro_current_user")
    if current_user is not None:
        st.success(
            f"Signed in as **{current_user.display_name}** (`{current_user.username}`, "
            f"role: `{current_user.role}`)"
        )
        with st.form("m6_profile_prefs_form"):
            new_name = st.text_input("Display Name", value=current_user.display_name)
            opt_in = st.checkbox(
                "Opt in to saving future voice check research summaries to My History "
                "(audio is never saved)",
                value=current_user.prediction_retention_opt_in,
            )
            if st.form_submit_button("Save Preferences"):
                try:
                    updated = update_user_profile_preferences(
                        conn, token, display_name=new_name, prediction_retention_opt_in=opt_in
                    )
                    st.session_state["voxneuro_current_user"] = updated
                    st.success("Preferences updated.")
                except Exception as exc:
                    st.error(f"Update failed: {exc}")

        if st.button("Sign Out", key="m6_signout_btn"):
            if token:
                revoke_session(conn, token)
            st.session_state.pop("voxneuro_auth_token", None)
            st.session_state.pop("voxneuro_current_user", None)
            st.success("Signed out safely.")
            st.rerun()
        return

    tab_login, tab_register, tab_reset = st.tabs(["Sign In", "Create Account", "Reset Password"])
    with tab_login:
        with st.form("m6_login_form"):
            ident = st.text_input("Username or Email")
            pw = st.text_input("Password", type="password")
            if st.form_submit_button("Sign In"):
                try:
                    user, raw_token = authenticate_user(conn, identifier=ident, password=pw)
                    st.session_state["voxneuro_auth_token"] = raw_token
                    st.session_state["voxneuro_current_user"] = user
                    st.success(f"Welcome back, {user.display_name}.")
                    st.rerun()
                except AuthorizationError as exc:
                    st.error(str(exc))
    with tab_register:
        with st.form("m6_register_form"):
            r_user = st.text_input("Choose a username (min 3 chars)")
            r_email = st.text_input("Email address")
            r_name = st.text_input("Display name")
            r_pw = st.text_input("Password (min 8 chars)", type="password")
            r_opt_in = st.checkbox(
                "Allow saving optional research summaries to my history", value=False
            )
            if st.form_submit_button("Create Participant Account"):
                try:
                    created = register_user(
                        conn,
                        username=r_user,
                        email=r_email,
                        password=r_pw,
                        display_name=r_name,
                        role="participant",
                        prediction_retention_opt_in=bool(r_opt_in),
                    )
                    user, raw_token = authenticate_user(
                        conn, identifier=created.username, password=r_pw
                    )
                    st.session_state["voxneuro_auth_token"] = raw_token
                    st.session_state["voxneuro_current_user"] = user
                    st.success("Account created and signed in.")
                    st.rerun()
                except Exception as exc:
                    st.error(f"Registration failed: {exc}")
    with tab_reset:
        with st.form("m6_reset_req_form"):
            reset_email = st.text_input("Registered email address")
            if st.form_submit_button("Generate Single-Use Reset Token"):
                tok = issue_password_reset_token(conn, email=reset_email)
                if tok:
                    st.info(
                        "Single-use local reset token generated (expires in 30 minutes). "
                        "Use the confirmation form below."
                    )
                    st.code(tok, language="text")
                else:
                    st.info("If the email matches an active account, a reset token is ready.")
        with st.form("m6_reset_complete_form"):
            tok_input = st.text_input("Reset token")
            new_pw = st.text_input("New password (min 8 chars)", type="password")
            if st.form_submit_button("Reset Password"):
                try:
                    complete_password_reset(conn, reset_token=tok_input, new_password=new_pw)
                    st.success("Password updated. You can now sign in with your new password.")
                except Exception as exc:
                    st.error(f"Password reset failed: {exc}")


def build_session_prediction(
    *,
    features: dict[str, Any] | None,
    quality_valid: bool,
    capture_origin: str,
    input_domain: str,
    conn: sqlite3.Connection | None,
    user: UserAccount | None,
) -> PredictionResult:
    """Execute fail-closed PredictionService with the active user/domain context."""
    from voxneuro.modeling.prediction import InputCaptureContext

    ctx = InputCaptureContext(
        capture_origin=capture_origin, task_type="sustained_vowel", verified_origin=False
    )
    return run_prediction_service(
        features=features,
        quality_valid=quality_valid,
        capture_context=ctx,
        input_domain=input_domain,
        conn=conn,
        model_id=st.session_state.get("voxneuro_selected_model_id"),
        user_id=user.user_id if user else None,
        participant_id=user.participant_id if user else None,
        allow_prediction_retention=bool(user and user.prediction_retention_opt_in),
    )
