"""Modern, accessible editorial digital-health design system and reusable M6 UI components."""

from __future__ import annotations

import html
from typing import Any

import streamlit as st

from voxneuro.modeling.prediction_service import M6_MEDICAL_DISCLAIMER, PredictionResult

M6_RESPONSIVE_CSS = """
<style>
:root {
  --vx-canvas: #F8F6F1;
  --vx-surface: #FFFFFF;
  --vx-surface-soft: #F3EFE7;
  --vx-ink: #1E232B;
  --vx-muted: #5B606A;
  --vx-accent: #B95E46;
  --vx-accent-dark: #9B4934;
  --vx-sage: #1F7A63;
  --vx-sage-bg: #EBF6F2;
  --vx-amber: #B4690E;
  --vx-amber-bg: #FEF6E6;
  --vx-border: rgba(30, 35, 43, 0.10);
  --vx-shadow: 0 8px 24px rgba(30, 35, 43, 0.05);
  --vx-radius: 14px;
}

html, body, [data-testid="stAppViewContainer"] {
  background: var(--vx-canvas) !important;
  color: var(--vx-ink);
  overflow-x: hidden !important;
}

.main .block-container {
  max-width: 1120px !important;
  padding-top: 1.5rem !important;
  padding-bottom: 3rem !important;
  padding-left: 1.5rem !important;
  padding-right: 1.5rem !important;
}

/* Focus visibility for keyboard accessibility */
button:focus-visible,
a:focus-visible,
input:focus-visible,
select:focus-visible,
[tabindex]:focus-visible {
  outline: 3px solid var(--vx-accent) !important;
  outline-offset: 2px !important;
}

.vx-brand-bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 0.75rem;
  padding: 0.85rem 1.25rem;
  background: var(--vx-surface);
  border: 1px solid var(--vx-border);
  border-radius: var(--vx-radius);
  box-shadow: var(--vx-shadow);
  margin-bottom: 0.85rem;
}

.vx-brand-left {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.vx-logo-dot {
  width: 12px;
  height: 12px;
  border-radius: 999px;
  background: linear-gradient(135deg, var(--vx-accent), #51445D);
}

.vx-brand-title {
  font-family: "Newsreader", "Georgia", serif;
  font-size: 1.3rem;
  font-weight: 700;
  color: var(--vx-ink);
  letter-spacing: -0.02em;
}

.vx-pill-badge {
  display: inline-block;
  padding: 0.25rem 0.65rem;
  border-radius: 999px;
  font-size: 0.75rem;
  font-weight: 700;
  letter-spacing: 0.04em;
  background: var(--vx-surface-soft);
  color: var(--vx-muted);
  border: 1px solid var(--vx-border);
}

.vx-disclaimer {
  background: var(--vx-amber-bg);
  border: 1px solid rgba(180, 105, 14, 0.25);
  border-left: 4px solid var(--vx-amber);
  border-radius: 10px;
  padding: 0.9rem 1.1rem;
  margin: 0.75rem 0 1.25rem 0;
  font-size: 0.92rem;
  line-height: 1.55;
  color: #4A2E05;
}

.vx-hero-card {
  background: linear-gradient(135deg, #FFFFFF 0%, #F7F2EA 100%);
  border: 1px solid var(--vx-border);
  border-radius: 18px;
  padding: 2rem;
  box-shadow: var(--vx-shadow);
  margin-bottom: 1.25rem;
}

.vx-hero-eyebrow {
  color: var(--vx-accent);
  font-size: 0.78rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  margin-bottom: 0.5rem;
}

.vx-card {
  background: var(--vx-surface);
  border: 1px solid var(--vx-border);
  border-radius: var(--vx-radius);
  padding: 1.25rem 1.35rem;
  box-shadow: var(--vx-shadow);
  margin-bottom: 1rem;
  height: 100%;
}

.vx-card h4 {
  margin: 0 0 0.45rem 0;
  color: var(--vx-ink);
  font-size: 1.05rem;
}

.vx-card p {
  margin: 0;
  color: var(--vx-muted);
  font-size: 0.92rem;
  line-height: 1.55;
}

.vx-stepper {
  display: flex;
  flex-wrap: wrap;
  gap: 0.45rem;
  margin: 0.5rem 0 1.15rem 0;
}

.vx-step-item {
  flex: 1 1 130px;
  padding: 0.5rem 0.7rem;
  border-radius: 10px;
  font-size: 0.80rem;
  border: 1px solid var(--vx-border);
  background: var(--vx-surface);
  color: var(--vx-muted);
}

.vx-step-active {
  background: #FCF0EC;
  border-color: var(--vx-accent);
  color: var(--vx-accent-dark);
  font-weight: 700;
}

.vx-step-done {
  background: var(--vx-sage-bg);
  border-color: rgba(31, 122, 99, 0.35);
  color: var(--vx-sage);
  font-weight: 600;
}

.vx-result-abstain {
  background: #FFF9F0;
  border: 1px solid rgba(180, 105, 14, 0.30);
  border-left: 5px solid var(--vx-amber);
  border-radius: var(--vx-radius);
  padding: 1.25rem 1.35rem;
  margin: 1rem 0;
}

.vx-result-score {
  background: var(--vx-sage-bg);
  border: 1px solid rgba(31, 122, 99, 0.30);
  border-left: 5px solid var(--vx-sage);
  border-radius: var(--vx-radius);
  padding: 1.25rem 1.35rem;
  margin: 1rem 0;
}

/* Tablet and mobile responsive refinements */
@media (max-width: 1024px) {
  .main .block-container {
    padding-left: 1rem !important;
    padding-right: 1rem !important;
  }
  .vx-hero-card {
    padding: 1.4rem;
  }
}

@media (max-width: 767px) {
  .vx-brand-bar {
    padding: 0.75rem 0.9rem;
  }
  .vx-hero-card {
    padding: 1.15rem;
  }
  .vx-step-item {
    flex: 1 1 46%;
  }
}
</style>
"""


def render_brand_bar(*, user_display: str | None = None, role: str | None = None) -> None:
    """Render accessible brand header bar with optional signed-in status."""
    right_badge = (
        f'<span class="vx-pill-badge">Signed in: {html.escape(user_display)} '
        f"({html.escape(role or 'participant')})</span>"
        if user_display
        else '<span class="vx-pill-badge">Experimental Research Platform · Not For Diagnosis</span>'
    )
    st.markdown(
        '<div class="vx-brand-bar" role="banner">'
        '<div class="vx-brand-left">'
        '<span class="vx-logo-dot" aria-hidden="true"></span>'
        '<span class="vx-brand-title">VoxNeuro</span>'
        '<span class="vx-pill-badge">Voice Biomarker Research</span>'
        "</div>"
        f"<div>{right_badge}</div>"
        "</div>",
        unsafe_allow_html=True,
    )


def render_medical_disclaimer() -> None:
    """Render the mandatory prominent non-diagnostic research disclaimer."""
    st.markdown(
        f'<div class="vx-disclaimer" role="note"><strong>Important Notice:</strong> '
        f"{html.escape(M6_MEDICAL_DISCLAIMER)}</div>",
        unsafe_allow_html=True,
    )


def render_stepper(steps: list[str], active_index: int) -> None:
    """Render accessible multi-step progress indicator."""
    items: list[str] = []
    for idx, label in enumerate(steps):
        cls = "vx-step-item"
        if idx < active_index:
            cls += " vx-step-done"
            prefix = "Done · "
        elif idx == active_index:
            cls += " vx-step-active"
            prefix = "Now · "
        else:
            prefix = ""
        items.append(f'<div class="{cls}">{idx + 1}. {html.escape(prefix + label)}</div>')
    st.markdown(
        f'<div class="vx-stepper" aria-label="Assessment steps">{"".join(items)}</div>',
        unsafe_allow_html=True,
    )


def render_plain_quality_summary(quality: Any, record: Any) -> None:
    """Render approachable plain-language recording quality feedback for ordinary users."""
    if quality.valid:
        st.success(
            f"Clear recording captured ({quality.duration_seconds:.1f} seconds at "
            f"{record.sample_rate:,} Hz). Sound quality is suitable for voice measurements."
        )
    else:
        st.error(
            "We could not measure this recording reliably because audio quality checks failed."
        )
        for err in quality.errors:
            st.write(f"• {err}")
        st.info(
            "Tip: Move to a quieter room, keep a steady distance from your microphone, and hold a "
            "comfortable 'ah' sound for 3 to 5 seconds."
        )


def render_prediction_outcome_card(prediction: PredictionResult) -> None:
    """Render plain-language research score OR honest fail-closed abstention explanation."""
    if prediction.abstained:
        reason_text = html.escape(
            prediction.abstention_reason
            or "No automated classification was generated for this recording."
        )
        st.markdown(
            '<div class="vx-result-abstain">'
            '<h4 style="margin:0 0 0.45rem 0; color:#7C4604;">'
            "No Research Classification Produced (Abstention)</h4>"
            f"<p style='margin:0 0 0.5rem 0; color:#4A2E05;'>{reason_text}</p>"
            "<p style='margin:0; font-size:0.85rem; color:#6B4E24;'>"
            "Your voice recording quality and descriptive measurements remain available for "
            "review or download, and nothing is stored permanently without permission.</p>"
            "</div>",
            unsafe_allow_html=True,
        )
    else:
        score_pct = f"{(prediction.research_score or 0.0) * 100:.1f}%"
        st.markdown(
            '<div class="vx-result-score">'
            '<h4 style="margin:0 0 0.45rem 0; color:#165B49;">Research Analysis Summary</h4>'
            f"<p style='margin:0 0 0.35rem 0;'><strong>Research band:</strong> "
            f"{html.escape(str(prediction.research_classification or 'RECORDED'))} "
            f"(experimental index: {html.escape(score_pct)})</p>"
            "<p style='margin:0; font-size:0.85rem; color:#245447;'>"
            f"Model {html.escape(prediction.model_version)} · "
            f"Calibration: {html.escape(prediction.calibration_status)}</p>"
            "</div>",
            unsafe_allow_html=True,
        )
    render_medical_disclaimer()
