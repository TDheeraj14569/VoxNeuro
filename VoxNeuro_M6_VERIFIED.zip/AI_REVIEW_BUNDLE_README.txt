VoxNeuro AI review bundle (M6)
========================

This ZIP contains the complete compact source package plus aggregate model-evaluation evidence.
The hashes below let a reviewer check the exact evidence files.

Scope and privacy
-----------------
- `review_evidence/` contains cohort summaries, fold metrics, and provenance receipts.
- Audio, participant-level feature/prediction rows, and model binaries are excluded.
- The review package includes aggregate exclusion counts and reasons;
  participant-level exclusion IDs are excluded for privacy.
  The supplemental dataset audit HTML contains aggregate counts only.
- The bundled feature-extraction receipt replaces its excluded-ID list with a count.
- UAMS results are internal estimates from a small, age-confounded cohort. They are not
  external or clinical validation. The app does not classify new microphone recordings.
- UCI is a separate pre-extracted feature benchmark; it does not validate raw-WAV processing.
- Exact evaluation settings and limits are in `configs/model_config.yaml`, `docs/methodology/`,
  and `docs/reports/MODEL_CARD.md`.

Evidence files
--------------
- `m2_age_subgroup_summary.csv` — SHA-256 `bc11d3e8bacd8fcce9e653279f71a789a5c0bf0923fde5c76055a83c5b9f40e2`
- `m2_analysis_receipt.json` — SHA-256 `d65f008eda097cab799b499f34674a5f179442ffe08cc417e7db8de169750758`
- `m2_attrition_analysis.html` — SHA-256 `119f8a32bb57494c735e2d394e1dce0a773a4beae8551af272868eeb7d00123f`
- `m2_attrition_summary.json` — SHA-256 `b09f086844fa5da44b25090c31f72283406c3cbe1521b390b159f6963298fe6f`
- `m2_bias_audit.html` — SHA-256 `b3a68edf4ad74c8ef2be951d121cbf3fe4dab9b0e24c5bedaa9ac03e0e82041f`
- `m2_comparator_metrics.csv` — SHA-256 `1e46600194f99f0834f3f53476ffe4096c02980e5b012e9db6c5fa89a495d087`
- `m2_demographic_audit.html` — SHA-256 `b71c0cea11abde166f5648dce6f7a30cbd6349d2613eb6f021958c320e1b65bd`
- `m2_demographic_summary.json` — SHA-256 `86bb4531282d8cd519fdbb9afab24f45104db0d0b469aef21bd19dcffe484ebf`
- `m2_feature_fdr_summary.csv` — SHA-256 `fc079c23860ca80f55bea5ea4a7fe3c2b04f04b1b4a1c5fcf8a7c367c6c437b6`
- `m2_matching_balance.html` — SHA-256 `15dd424dd05ecd3d9e629621dc2c5e372a7785bbe6c3218dc2ef4d72d55730fa`
- `m2_matching_sensitivity.csv` — SHA-256 `f5933d686f43abda0ce7a9b4e1019f07f8bab90931afb25b79628c27b4f39830`
- `m2_model_comparison.html` — SHA-256 `e7a86a5655240e81f9bb36acab54916a742a84c4137b55e25622cac66b2d6d3f`
- `m2_paired_incremental_voice.csv` — SHA-256 `6b1fdecf9ea64519f7f6a97924aa78a6761d81e65f52d0cf7689352f0169c762`
- `m2_sex_subgroup_summary.csv` — SHA-256 `53e4df97e41b897d7bc5a2e7b796e8f25d94a1ef645101b989c149f7129b4f4f`
- `m3_implementation_test_summary.json` — SHA-256 `eb19801f720d889767d4e13631932a27b4394c1676afb5a0da5cfd2c8b2f9b7e`
- `m3_provenance_summary.json` — SHA-256 `65931f670a6f09ca0b34dabe0abc94e7a7472d16eaa953906744a6b3ea872f0c`
- `m3_synthetic_fixture_verification.json` — SHA-256 `1ee464d4307a10780e4a61abafe5af7902a1b6e4084a020e9e6d32a5a55ae099`
- `m3_task_feature_contract.csv` — SHA-256 `3dc96d65e1fcef1706f366814edb939174bb215b9bebdb3204e2c9d7d471715d`
- `m3_task_schema_registry.json` — SHA-256 `2681742185d49f5a19dac0bb9b9504f0178a7bd1f1c025d474a3efb577eb129d`
- `m4_authorization_registry_verification.json` — SHA-256 `eda6391b3e6dd6d157f56575d0aea1bca2859397902651c0e7070f2b70fcee57`
- `m4_dataset_access_authentication_summary.json` — SHA-256 `af42b339c19aff93031275e37a23fa167b7eb6462de14aba9d2d1ed79e885fe4`
- `m4_domain_assessment.json` — SHA-256 `b531d50f94076b5792c10bb918dc6a6b8709b693bbbffea7e7bc9ddce41122fa`
- `m4_domain_registry.json` — SHA-256 `0430add4ef39fbb583e2beaf7b1f10c67c22cd750f1c138cb0be1d5e721d38e1`
- `m4_domain_shift_summary.csv` — SHA-256 `70217dac74458734b99b9ea61668902c208df7aaa11a11e3350f213bcec96f0a`
- `m4_domain_shift_summary.json` — SHA-256 `694227e11e0e81e7f4c0daead33e2962499fefe388eca53c31f15c299e02d5a9`
- `m4_provenance_summary.json` — SHA-256 `8ec4ce7cb4115e309fa07dc7b06849c633987564dc27a34cbd1197ec3cfb4f3b`
- `m4_review_manifest.json` — SHA-256 `bb8141231f9bdc60a1d15230c49843b434d4d7a171d5c3733fc7b1a5b179efc1`
- `m4_reviewer_authorization_summary.json` — SHA-256 `aa52bf88846b89e37d80c9ddf150d99a06f8e67d38379f2a0fc2817757345f29`
- `m4_safety_gate_test_summary.json` — SHA-256 `ce35d63d4f642a7e95bdd1890a580289302cff7c4a35d57ad783863f34e18323`
- `m4_source_authorization_summary.json` — SHA-256 `0c11f3f0fcd8dc4f8c5914456855d20fd3f79b8d837a13efc09d0d08fdd3c400`
- `m5_consent_governance_summary.json` — SHA-256 `a13cebe9c2aac6bd41232494081497aed37a2261446800ee393caacd6248f2d0`
- `m5_database_schema_summary.json` — SHA-256 `6678c26a0f13eb0c58d4078ea87a0a04845d8d174626d2cf7d3378aac4f44323`
- `m5_dataset_access_summary.json` — SHA-256 `4e14375b4659117afe8efbd3be6cebfe43cbb3caaf826da4fa0576f50b9de4cd`
- `m5_longitudinal_analysis_summary.json` — SHA-256 `5d94215546b12d7eebf1e3d09712041580f913a1aaa28a9c7a3a9036bd04284a`
- `m5_privacy_audit_summary.json` — SHA-256 `3412e1a2a80d2f06be609733a71eeb5b30b2eef690ec6d8857d5dbfdc0fd09dc`
- `m5_provenance_summary.json` — SHA-256 `0cad662e35c7228abcabd2328bda5713fa315c631784c7dc1d3e213c89270685`
- `m5_quality_control_summary.json` — SHA-256 `8d3d0891dc8410366644768a80485e47ea2f052b662a6edccb45b536f92f1df7`
- `m5_review_manifest.json` — SHA-256 `11131d29e5a6c0ab84b394358492515ad2c972b19f71615afeb390554b53711c`
- `m5_session_pipeline_summary.json` — SHA-256 `a44775760190a45b732aee518c09fa3a526d003ec17d826f27f0659b26102207`
- `m5_study_registry_summary.json` — SHA-256 `f346ad1ab1ddada384f0f8983090d8cb7e6678696ce348e56c03bcad5f083952`
- `m5_test_summary.json` — SHA-256 `988a2dc4eb40dc67cda2722369000c068da82fd7a2bc38461255923ec9b9791c`
- `m6_database_and_auth_summary.json` — SHA-256 `8a88a599b6d987869074245f7ebc26aed4fd3448a1c3999828fb81f9f0a27c3b`
- `m6_dataset_readiness.json` — SHA-256 `c11841e2fe0c8c291787782c313344b201bc28f7e844c2573fa79ae5e20089d7`
- `m6_experiment_summary.json` — SHA-256 `db8b3b49ab1d48134d8ce0b69bea51f227087ecd55fe44aa6a4f011fc07e1306`
- `m6_model_card.html` — SHA-256 `a992820efcd70a92e172f4f5a392a3901fdd177a0a8f2a00841212d563ef09fc`
- `m6_model_card.json` — SHA-256 `7ac41b6dbf3f3d6c55d38ac49d68a9c6e6518e34248e5fcf3e7950d272968960`
- `m6_prediction_service_summary.json` — SHA-256 `436c1c40305f747c375e88b984acb7004ff5411b270cf9d74327378ccb506122`
- `m6_provenance_summary.json` — SHA-256 `c26b3defb6f920beee3a3a14128afec4fe432d9c8ce05d0a1910aff20d751fd8`
- `m6_review_manifest.json` — SHA-256 `6864af58d84774de3ae90947d7300bafb26fad082dc6bf97fe1d4a36bb8ffcea`
- `m6_test_summary.json` — SHA-256 `bb54eb872319517a8ece77accc201f92434acafdb0ebe6beca23b35d553c20db`
- `m6_ui_architecture_summary.json` — SHA-256 `0b30ac57131f16763a20cca3301ddfb14548e1648a495f95aec780bb2819aef3`
- `uams_dataset_audit.html` — SHA-256 `ce9a1c6de68f0ad419edbe275402d4128e7f23aa9e83e0715915bb7c59f8e747`
- `uams_feature_extraction_receipt.json` — SHA-256 `0c7c2201fd3d45b6f3efa3b365add55d1358b1600423ae9a3dd46aac9a968031`
- `uams_grouped_evaluation_receipt.json` — SHA-256 `18a7f9b5562212af20eafa7434b1df004222f739902e69ccb09d02dfbef3360f`
- `uams_nested_evaluation.html` — SHA-256 `10df2982a54ad30e4d256d9d4a6965bfafa60f6dccfc7ed5d5e39dca02206594`
- `uams_nested_evaluation_receipt.json` — SHA-256 `0822e45c9cc8cdf26c4561689b316040152fc408c916de15d095bbccadb920fe`
- `uams_nested_fold_metrics.csv` — SHA-256 `eb0c9c346e4447ed042d47cccdbed844c10251afcc7945b73da3096bf8321ecc`
- `uams_nested_summary.csv` — SHA-256 `bc012fb78116c8dd666869a0fff6d371580a66664d42036b05cd69f6da26b75d`
- `uci_duplicate_sensitivity.csv` — SHA-256 `795ef6524fc91f058b2d62a5882d491e3ec31fc6c39db6501f0a3cf4b37aab62`
- `uci_evaluation_receipt.json` — SHA-256 `c10d6c050e1c87811b43a390967a4450d69f458e3b4686a4c9df78cd038af4d7`
- `uci_grouped_fold_metrics.csv` — SHA-256 `9f2ce6abdce5fb3a3c314ff6d5e6168e671d7a9302087435ad89e05c3497496a`

The source inventory excludes this README and `review_evidence/`: they are review
attachments, not project source files.
