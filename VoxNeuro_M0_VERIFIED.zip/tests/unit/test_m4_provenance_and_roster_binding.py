"""Unit tests for M4 participant independence, roster binding, and receipt verification."""

from __future__ import annotations

import hashlib

import pandas as pd
import pytest

from voxneuro.config import load_config
from voxneuro.features.schema import (
    FEATURE_NAMES,
    SCHEMA_VERSION,
    configuration_fingerprint,
    feature_config_fingerprint,
    schema_fingerprint,
)
from voxneuro.modeling.domain_evaluation import (
    FROZEN_REFERENCE_MODEL_SHA256,
    EvaluationProvenanceReceipt,
    create_participant_independence_attestation,
    verify_evaluation_provenance_receipt,
    verify_participant_independence,
    verify_participant_independence_attestation,
)
from voxneuro.modeling.domain_registry import load_domain_registry
from voxneuro.provenance import project_code_fingerprint
from voxneuro.study.consent import register_dataset_access
from voxneuro.study.database import get_connection, run_migrations
from voxneuro.study.schema import DatasetAccessRecord


@pytest.fixture
def m4_setup(tmp_path, monkeypatch):
    test_key = "test_hmac_secret_key_m4_2026"
    monkeypatch.setenv("VOXNEURO_HMAC_KEY", test_key)

    ref_csv = tmp_path / "ref_uams.csv"
    ref_row = {"participant_id": "R01", "diagnostic_group": "HC"}
    for f in FEATURE_NAMES:
        ref_row[f] = 0.1
    pd.DataFrame([ref_row]).to_csv(ref_csv, index=False)
    ref_sha = hashlib.sha256(ref_csv.read_bytes()).hexdigest()

    cand_csv = tmp_path / "cand_neurovoz.csv"
    cand_row = {"participant_id": "C01", "diagnostic_group": "PD"}
    for f in FEATURE_NAMES:
        cand_row[f] = 0.2
    pd.DataFrame([cand_row]).to_csv(cand_csv, index=False)
    cand_sha = hashlib.sha256(cand_csv.read_bytes()).hexdigest()

    ref_roster = tmp_path / "ref_roster.txt"
    ref_roster.write_text("participant_id\nR01\n", encoding="utf-8")
    cand_roster = tmp_path / "cand_roster.txt"
    cand_roster.write_text("participant_id\nC01\n", encoding="utf-8")

    reviewers = {"auditor.jane@voxneuro.org"}
    sources = {
        "uams_figshare_verified_roster": {
            "dataset_id": "uams_figshare_23849127",
            "authorization_ref": "UAMS-IRB-EXEMPT-2023",
        },
        "neurovoz_authorized_roster": {
            "dataset_id": "neurovoz_corpus",
            "authorization_ref": "CANDIDATE-DUA-2026-V1",
        },
    }

    dua_fp = hashlib.sha256(b"authorized-neurovoz-dua-v1").hexdigest()
    db_file = tmp_path / "m4_gov.db"
    run_migrations(db_file)
    conn = get_connection(db_file)
    auth_rec = DatasetAccessRecord(
        dataset_id="neurovoz_corpus",
        dataset_version="v1",
        dataset_owner="Hospital General Universitario Gregorio Maranon",
        license_type="DUA_RESTRICTED",
        access_approval_state="APPROVED",
        dua_state="ACTIVE",
        permitted_tasks=["sustained_vowel"],
        permitted_data_processing_operations=["frozen_model_evaluation"],
        storage_restrictions="encrypted_research_vault",
        publication_restrictions="aggregate_only",
        expiration_date="2028-12-31",
        source_documentation="CANDIDATE-DUA-2026-V1-SIGNED",
        dua_document_fingerprint=dua_fp,
    )
    register_dataset_access(conn, auth_rec)
    conn.commit()

    att = create_participant_independence_attestation(
        reference_dataset_id="uams_figshare_23849127",
        reference_dataset_version="v1",
        candidate_dataset_id="neurovoz_corpus",
        candidate_dataset_version="v1",
        reference_roster_path=ref_roster,
        candidate_roster_path=cand_roster,
        reference_roster_source="uams_figshare_verified_roster",
        reference_authorization_ref="UAMS-IRB-EXEMPT-2023",
        candidate_roster_source="neurovoz_authorized_roster",
        candidate_authorization_ref="CANDIDATE-DUA-2026-V1",
        identity_basis_type="authorized_crosswalk",
        reviewer_identity="auditor.jane@voxneuro.org",
        authorized_reviewers=reviewers,
        authorized_sources=sources,
        key=test_key,
    )

    feat_fp = feature_config_fingerprint(load_config("feature_config.yaml"))
    prep_fp = configuration_fingerprint(load_config("audio_config.yaml"))
    code_fp = project_code_fingerprint()

    receipt = EvaluationProvenanceReceipt(
        candidate_domain_id="neurovoz_studio",
        dataset_id="neurovoz_corpus",
        dataset_version="v1",
        dataset_source="Hospital General Universitario Gregorio Marañón",
        authorization_status="AUTHORIZED_DUA",
        task_identifier="sustained_vowel",
        feature_schema_version=SCHEMA_VERSION,
        feature_schema_fingerprint=schema_fingerprint(),
        feature_config_fingerprint=feat_fp,
        preprocessing_config_fingerprint=prep_fp,
        code_fingerprint=code_fp,
        reference_feature_table_sha256=ref_sha,
        candidate_feature_table_sha256=cand_sha,
        num_recordings=1,
        num_unique_participants=1,
        diagnostic_label_provenance="clinical_neurologist",
        participant_overlap_status="VERIFIED_DISJOINT",
        duplicate_participant_count=0,
        duplicate_recording_count=0,
        feature_validation_status="PASSED",
        quality_exclusion_count=0,
        evaluation_protocol_id="VOXNEURO-M4-EXT-VAL-2026-V1",
        timestamp_utc="2026-11-12T12:00:00Z",
        independence_attestation=att.to_dict(),
        dua_expiration_date="2028-12-31",
        dua_document_fingerprint=dua_fp,
        permitted_operations=["frozen_model_evaluation"],
        frozen_model_sha256=FROZEN_REFERENCE_MODEL_SHA256,
        key_id="voxneuro-key-v1",
    )
    rec_hash = receipt.compute_sha256()
    rec_hmac = receipt.compute_hmac(test_key)
    valid_receipt = EvaluationProvenanceReceipt(
        **{**receipt.to_dict(), "receipt_sha256": rec_hash, "receipt_hmac": rec_hmac}
    )

    try:
        yield {
            "test_key": test_key,
            "ref_csv": ref_csv,
            "cand_csv": cand_csv,
            "ref_roster": ref_roster,
            "cand_roster": cand_roster,
            "reviewers": reviewers,
            "sources": sources,
            "conn": conn,
            "auth_rec": auth_rec,
            "att": att,
            "valid_receipt": valid_receipt,
        }
    finally:
        conn.close()


def test_independence_verification_requires_common_identity_basis(m4_setup):
    """Disparate pseudonym systems without a crosswalk return INDEPENDENCE_NOT_VERIFIED."""
    res = verify_participant_independence(
        ["R01", "R02"],
        ["C01", "C02"],
        key=m4_setup["test_key"],
        identity_basis_type="disparate_pseudonyms",  # No common identity basis
    )
    assert res["overlap_status"] == "INDEPENDENCE_NOT_VERIFIED"
    assert res["is_disjoint"] is False
    assert "independently assigned pseudonyms cannot establish" in res["reason"]


def test_independence_attestation_to_roster_binding(m4_setup):
    """Attestation contains exact roster checksums, roster fingerprint, and explicit reviewer."""
    att = m4_setup["att"]
    assert (
        att.reference_roster_sha256
        == hashlib.sha256(m4_setup["ref_roster"].read_bytes()).hexdigest()
    )
    assert len(att.reference_roster_sha256) == 64
    assert (
        att.candidate_roster_sha256
        == hashlib.sha256(m4_setup["cand_roster"].read_bytes()).hexdigest()
    )
    assert len(att.candidate_roster_sha256) == 64
    assert att.roster_fingerprint != ""
    assert att.reviewer_identity == "auditor.jane@voxneuro.org"
    assert att.authentication_method == "HMAC-SHA256"


def test_attestation_rejects_missing_provenance_defaults(m4_setup):
    """Creating attestation without explicit roster paths/refs/reviewer must fail."""
    with pytest.raises(ValueError, match="INDEPENDENCE_NOT_VERIFIED"):
        create_participant_independence_attestation(
            reference_dataset_id="uams_figshare_23849127",
            reference_dataset_version="v1",
            candidate_dataset_id="neurovoz_corpus",
            candidate_dataset_version="v1",
            key=m4_setup["test_key"],
        )


def test_attestation_rejects_tampered_source_roster_file(m4_setup):
    """Modifying a source roster file after signing invalidates attestation verification."""
    ok, _ = verify_participant_independence_attestation(
        m4_setup["att"],
        expected_reference=("uams_figshare_23849127", "v1"),
        expected_candidate=("neurovoz_corpus", "v1"),
        key=m4_setup["test_key"],
        reference_roster_path=m4_setup["ref_roster"],
        candidate_roster_path=m4_setup["cand_roster"],
        authorized_reviewers=m4_setup["reviewers"],
        authorized_sources=m4_setup["sources"],
    )
    assert ok

    # Tamper candidate roster file bytes (add participant / alter file)
    m4_setup["cand_roster"].write_text("participant_id\nC01\nC99\n", encoding="utf-8")
    ok_after, reason = verify_participant_independence_attestation(
        m4_setup["att"],
        expected_reference=("uams_figshare_23849127", "v1"),
        expected_candidate=("neurovoz_corpus", "v1"),
        key=m4_setup["test_key"],
        reference_roster_path=m4_setup["ref_roster"],
        candidate_roster_path=m4_setup["cand_roster"],
        authorized_reviewers=m4_setup["reviewers"],
        authorized_sources=m4_setup["sources"],
    )
    assert not ok_after
    assert "INDEPENDENCE_NOT_VERIFIED" in reason


def test_attestation_rejects_unauthorized_reviewer_or_source(m4_setup):
    """Attestation fails closed for unauthorized reviewer identity or source ref."""
    ok_rev, reason_rev = verify_participant_independence_attestation(
        m4_setup["att"],
        expected_reference=("uams_figshare_23849127", "v1"),
        expected_candidate=("neurovoz_corpus", "v1"),
        key=m4_setup["test_key"],
        reference_roster_path=m4_setup["ref_roster"],
        candidate_roster_path=m4_setup["cand_roster"],
        authorized_reviewers={"different.reviewer@voxneuro.org"},
        authorized_sources=m4_setup["sources"],
    )
    assert not ok_rev
    assert "INDEPENDENCE_NOT_VERIFIED" in reason_rev

    ok_src, reason_src = verify_participant_independence_attestation(
        m4_setup["att"],
        expected_reference=("uams_figshare_23849127", "v1"),
        expected_candidate=("neurovoz_corpus", "v1"),
        key=m4_setup["test_key"],
        reference_roster_path=m4_setup["ref_roster"],
        candidate_roster_path=m4_setup["cand_roster"],
        authorized_reviewers=m4_setup["reviewers"],
        authorized_sources={"other": "OTHER-REF"},
    )
    assert not ok_src
    assert "INDEPENDENCE_NOT_VERIFIED" in reason_src


def test_receipt_rejects_forged_approval_against_pending_or_expired_db_dua(m4_setup):
    """Receipt claiming AUTHORIZED_DUA fails when DB DUA is PENDING, expired, or scoped out."""
    # 1. Pending in DB despite signed receipt claiming AUTHORIZED_DUA
    pending_rec = DatasetAccessRecord(
        **{**m4_setup["auth_rec"].to_dict(), "access_approval_state": "PENDING"}
    )
    register_dataset_access(m4_setup["conn"], pending_rec)
    m4_setup["conn"].commit()
    ok_p, reason_p = verify_evaluation_provenance_receipt(
        m4_setup["valid_receipt"],
        m4_setup["cand_csv"],
        m4_setup["ref_csv"],
        key=m4_setup["test_key"],
        reference_roster_path=m4_setup["ref_roster"],
        candidate_roster_path=m4_setup["cand_roster"],
        authorized_reviewers=m4_setup["reviewers"],
        authorized_sources=m4_setup["sources"],
        study_conn=m4_setup["conn"],
    )
    assert not ok_p
    assert "DATASET_AUTHORIZATION_NOT_VERIFIED" in reason_p

    # 2. Expired in DB
    expired_rec = DatasetAccessRecord(
        **{**m4_setup["auth_rec"].to_dict(), "expiration_date": "2020-01-01"}
    )
    register_dataset_access(m4_setup["conn"], expired_rec)
    m4_setup["conn"].commit()
    ok_e, reason_e = verify_evaluation_provenance_receipt(
        m4_setup["valid_receipt"],
        m4_setup["cand_csv"],
        m4_setup["ref_csv"],
        key=m4_setup["test_key"],
        reference_roster_path=m4_setup["ref_roster"],
        candidate_roster_path=m4_setup["cand_roster"],
        authorized_reviewers=m4_setup["reviewers"],
        authorized_sources=m4_setup["sources"],
        study_conn=m4_setup["conn"],
    )
    assert not ok_e
    assert "DATASET_AUTHORIZATION_NOT_VERIFIED" in reason_e

    # 3. Operation not permitted in DB
    disallowed_op_rec = DatasetAccessRecord(
        **{
            **m4_setup["auth_rec"].to_dict(),
            "permitted_data_processing_operations": ["statistical_audit"],
        }
    )
    register_dataset_access(m4_setup["conn"], disallowed_op_rec)
    m4_setup["conn"].commit()
    ok_o, reason_o = verify_evaluation_provenance_receipt(
        m4_setup["valid_receipt"],
        m4_setup["cand_csv"],
        m4_setup["ref_csv"],
        key=m4_setup["test_key"],
        reference_roster_path=m4_setup["ref_roster"],
        candidate_roster_path=m4_setup["cand_roster"],
        authorized_reviewers=m4_setup["reviewers"],
        authorized_sources=m4_setup["sources"],
        study_conn=m4_setup["conn"],
    )
    assert not ok_o
    assert "DATASET_AUTHORIZATION_NOT_VERIFIED" in reason_o


def test_receipt_rejects_unregistered_key_id(m4_setup):
    """Receipt with unknown key_id must be rejected."""
    bad_key_rec = EvaluationProvenanceReceipt(
        **{**m4_setup["valid_receipt"].to_dict(), "key_id": "retired_key_v0", "receipt_hmac": ""}
    )
    signed_bad = EvaluationProvenanceReceipt(
        **{
            **bad_key_rec.to_dict(),
            "receipt_sha256": bad_key_rec.compute_sha256(),
            "receipt_hmac": bad_key_rec.compute_hmac(m4_setup["test_key"]),
        }
    )
    is_ok, reason = verify_evaluation_provenance_receipt(
        signed_bad,
        m4_setup["cand_csv"],
        m4_setup["ref_csv"],
        key=m4_setup["test_key"],
        study_conn=m4_setup["conn"],
    )
    assert not is_ok
    assert "unknown, retired, or invalid" in reason


def test_receipt_rejects_dataset_id_mismatch(m4_setup):
    """Receipt with dataset_id differing from registered domain metadata is rejected."""
    bad_ds_rec = EvaluationProvenanceReceipt(
        **{
            **m4_setup["valid_receipt"].to_dict(),
            "dataset_id": "unregistered_dataset_xyz",
            "receipt_hmac": "",
        }
    )
    signed_bad = EvaluationProvenanceReceipt(
        **{
            **bad_ds_rec.to_dict(),
            "receipt_sha256": bad_ds_rec.compute_sha256(),
            "receipt_hmac": bad_ds_rec.compute_hmac(m4_setup["test_key"]),
        }
    )
    is_ok, reason = verify_evaluation_provenance_receipt(
        signed_bad,
        m4_setup["cand_csv"],
        m4_setup["ref_csv"],
        key=m4_setup["test_key"],
        study_conn=m4_setup["conn"],
    )
    assert not is_ok
    assert "Dataset ID mismatch" in reason


def test_receipt_rejects_model_sha_mismatch(m4_setup):
    """Receipt with missing or incorrect frozen model SHA is rejected."""
    bad_model_rec = EvaluationProvenanceReceipt(
        **{
            **m4_setup["valid_receipt"].to_dict(),
            "frozen_model_sha256": "00" * 32,
            "receipt_hmac": "",
        }
    )
    signed_bad = EvaluationProvenanceReceipt(
        **{
            **bad_model_rec.to_dict(),
            "receipt_sha256": bad_model_rec.compute_sha256(),
            "receipt_hmac": bad_model_rec.compute_hmac(m4_setup["test_key"]),
        }
    )
    is_ok, reason = verify_evaluation_provenance_receipt(
        signed_bad,
        m4_setup["cand_csv"],
        m4_setup["ref_csv"],
        key=m4_setup["test_key"],
        reference_roster_path=m4_setup["ref_roster"],
        candidate_roster_path=m4_setup["cand_roster"],
        authorized_reviewers=m4_setup["reviewers"],
        authorized_sources=m4_setup["sources"],
        study_conn=m4_setup["conn"],
    )
    assert not is_ok
    assert "Frozen model SHA-256 mismatch" in reason


def test_receipt_rejects_feature_config_fingerprint_mismatch(m4_setup):
    """Receipt with mismatched feature config fingerprint is rejected."""
    bad_fp_rec = EvaluationProvenanceReceipt(
        **{
            **m4_setup["valid_receipt"].to_dict(),
            "feature_config_fingerprint": "bad_fp" * 16,
            "receipt_hmac": "",
        }
    )
    signed_bad = EvaluationProvenanceReceipt(
        **{
            **bad_fp_rec.to_dict(),
            "receipt_sha256": bad_fp_rec.compute_sha256(),
            "receipt_hmac": bad_fp_rec.compute_hmac(m4_setup["test_key"]),
        }
    )
    is_ok, reason = verify_evaluation_provenance_receipt(
        signed_bad,
        m4_setup["cand_csv"],
        m4_setup["ref_csv"],
        key=m4_setup["test_key"],
        reference_roster_path=m4_setup["ref_roster"],
        candidate_roster_path=m4_setup["cand_roster"],
        authorized_reviewers=m4_setup["reviewers"],
        authorized_sources=m4_setup["sources"],
        study_conn=m4_setup["conn"],
    )
    assert not is_ok
    assert "Feature configuration fingerprint mismatch" in reason


def test_receipt_rejects_candidate_table_with_non_numeric_features(m4_setup, tmp_path):
    """Receipt validation parses candidate table and rejects non-numeric or NaN features."""
    bad_csv = tmp_path / "bad_non_num.csv"
    row = {"participant_id": "C01", "diagnostic_group": "PD"}
    for f in FEATURE_NAMES:
        row[f] = 0.5
    row["jitter_local"] = "NOT_A_NUMBER"
    pd.DataFrame([row]).to_csv(bad_csv, index=False)
    bad_sha = hashlib.sha256(bad_csv.read_bytes()).hexdigest()

    rec = EvaluationProvenanceReceipt(
        **{
            **m4_setup["valid_receipt"].to_dict(),
            "candidate_feature_table_sha256": bad_sha,
            "receipt_hmac": "",
        }
    )
    signed = EvaluationProvenanceReceipt(
        **{
            **rec.to_dict(),
            "receipt_sha256": rec.compute_sha256(),
            "receipt_hmac": rec.compute_hmac(m4_setup["test_key"]),
        }
    )
    is_ok, reason = verify_evaluation_provenance_receipt(
        signed,
        bad_csv,
        m4_setup["ref_csv"],
        key=m4_setup["test_key"],
        reference_roster_path=m4_setup["ref_roster"],
        candidate_roster_path=m4_setup["cand_roster"],
        authorized_reviewers=m4_setup["reviewers"],
        authorized_sources=m4_setup["sources"],
        study_conn=m4_setup["conn"],
    )
    assert not is_ok
    assert "not numeric" in reason


def test_evaluate_external_domain_cli_fails_closed_without_governance_flags(tmp_path):
    """scripts/evaluate_external_domain.py exits non-zero if governance args are omitted."""
    import subprocess
    import sys

    cand_csv = tmp_path / "cand.csv"
    cand_csv.write_text("participant_id,diagnostic_group\nC1,PD\n", encoding="utf-8")
    receipt_json = tmp_path / "receipt.json"
    receipt_json.write_text("{}", encoding="utf-8")

    proc = subprocess.run(
        [
            sys.executable,
            "scripts/evaluate_external_domain.py",
            "--features-path",
            str(cand_csv),
            "--receipt-path",
            str(receipt_json),
            "--out-dir",
            str(tmp_path / "out"),
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode != 0
    combined = proc.stdout + proc.stderr
    assert "NOT_VERIFIED" in combined


def test_italian_ipvs_acquisition_fields_allow_unknown():
    """Italian IPVS metadata correctly sets unknown/null acquisition fields without crash."""
    reg = load_domain_registry()
    ipvs = reg.get_domain("italian_parkinsons_headset")
    assert ipvs.metadata.original_sample_rate is None
    assert ipvs.metadata.bit_depth is None
    assert ipvs.metadata.channel_count is None
    assert ipvs.metadata.device_category == "unknown"
    assert ipvs.metadata.microphone_type == "unknown"
    assert ipvs.research_evaluation_eligible is False
