"""Evaluate candidate external recording domain against the frozen reference model."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd

from voxneuro.modeling.domain_evaluation import (
    evaluate_frozen_model_on_cohort,
    load_frozen_reference_model,
    verify_evaluation_provenance_receipt,
    verify_frozen_model_identity,
)
from voxneuro.modeling.domain_registry import load_domain_registry
from voxneuro.modeling.domain_shift import (
    compare_acquisition_metadata,
    compute_feature_shift,
    summarize_domain_shift,
)
from voxneuro.study.database import get_connection

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--domain", default="neurovoz_studio", help="Candidate domain identifier")
    parser.add_argument(
        "--features-path", type=Path, default=None, help="Path to extracted features CSV"
    )
    parser.add_argument(
        "--receipt-path", type=Path, default=None, help="Path to validated provenance receipt JSON"
    )
    parser.add_argument(
        "--study-db",
        type=Path,
        default=None,
        help="Path to SQLite study governance database containing authoritative dataset_access",
    )
    parser.add_argument(
        "--reference-roster-path",
        type=Path,
        default=None,
        help="Path to reference dataset participant roster file",
    )
    parser.add_argument(
        "--candidate-roster-path",
        type=Path,
        default=None,
        help="Path to candidate dataset participant roster file",
    )
    parser.add_argument(
        "--authorized-reviewers",
        default="",
        help="Comma-separated authorized reviewer identities for attestation validation",
    )
    parser.add_argument(
        "--authorized-sources-json",
        type=Path,
        default=None,
        help="Path to JSON file mapping authorized roster sources and references",
    )
    parser.add_argument(
        "--out-dir", type=Path, default=ROOT / "artifacts" / "reports" / "domain_validation"
    )
    parser.add_argument("--json", action="store_true", help="Print summary as JSON")
    args = parser.parse_args()

    registry = load_domain_registry()
    if not registry.is_registered(args.domain):
        print(f"Error: Unknown domain {args.domain!r}")
        return 1

    entry = registry.get_domain(args.domain)
    ref_entry = registry.get_domain("uams_telephone")
    args.out_dir.mkdir(parents=True, exist_ok=True)

    acq_diffs = compare_acquisition_metadata(ref_entry.metadata.to_dict(), entry.metadata.to_dict())
    model_identity = verify_frozen_model_identity()

    if args.features_path is None or not args.features_path.is_file():
        summary = {
            "domain_id": entry.domain_id,
            "status": "FRAMEWORK_VERIFIED_DOMAIN_VALIDATION_PENDING",
            "model_artifact_status": model_identity["status"],
            "decision_rationale": (
                f"Candidate domain {entry.domain_id!r} evaluation framework verified. "
                "Independent raw audio or extracted features are not present in "
                "the local workspace. "
                "Validation is pending execution of a licensed Data Use Agreement."
            ),
            "acquisition_differences": acq_diffs,
            "inference_eligible": False,
        }
        report_file = args.out_dir / f"{entry.domain_id}_evaluation_status.json"
        report_file.write_text(json.dumps(summary, indent=2), encoding="utf-8")

        if args.json:
            print(json.dumps(summary, indent=2))
        else:
            print(f"=== Domain Evaluation Status: {entry.domain_id} ===")
            print(f"Status: {summary['status']}")
            print(f"Model Status: {summary['model_artifact_status']}")
            print(f"Rationale: {summary['decision_rationale']}")
            print(f"Report written to: {report_file}")
        return 0

    if not model_identity.get("verified"):
        print(f"Error: {model_identity['status']}: {model_identity['reason']}")
        return 1

    # If features are supplied, provenance receipt, study DB, rosters, and authorities are required
    if args.receipt_path is None or not args.receipt_path.is_file():
        print(
            "Error: Provenance receipt is required for external feature evaluation "
            "(--receipt-path). Status: INDEPENDENCE_NOT_VERIFIED"
        )
        return 1

    if args.study_db is None or not args.study_db.is_file():
        print(
            "Error: Authoritative study governance database (--study-db) is required. "
            "Status: DATASET_AUTHORIZATION_NOT_VERIFIED"
        )
        return 1

    if (
        args.reference_roster_path is None
        or not args.reference_roster_path.is_file()
        or args.candidate_roster_path is None
        or not args.candidate_roster_path.is_file()
    ):
        print(
            "Error: Source participant roster paths (--reference-roster-path and "
            "--candidate-roster-path) are required. Status: INDEPENDENCE_NOT_VERIFIED"
        )
        return 1

    reviewers = {r.strip() for r in str(args.authorized_reviewers).split(",") if r.strip()}
    if not reviewers:
        print(
            "Error: --authorized-reviewers is required for attestation verification. "
            "Status: INDEPENDENCE_NOT_VERIFIED"
        )
        return 1

    if args.authorized_sources_json is None or not args.authorized_sources_json.is_file():
        print(
            "Error: --authorized-sources-json is required for source authority verification. "
            "Status: INDEPENDENCE_NOT_VERIFIED"
        )
        return 1

    try:
        receipt_data = json.loads(args.receipt_path.read_text(encoding="utf-8"))
        authorized_sources = json.loads(args.authorized_sources_json.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"Error reading provenance or authorization JSON: {exc}")
        return 1

    uams_path = ROOT / "data" / "processed" / "voice_features.csv"
    conn = get_connection(args.study_db)
    try:
        is_valid, reason = verify_evaluation_provenance_receipt(
            receipt_data,
            candidate_csv_path=args.features_path,
            reference_csv_path=uams_path if uams_path.is_file() else None,
            registry=registry,
            reference_roster_path=args.reference_roster_path,
            candidate_roster_path=args.candidate_roster_path,
            authorized_reviewers=reviewers,
            authorized_sources=authorized_sources,
            study_conn=conn,
        )
    finally:
        conn.close()
    if not is_valid:
        print(f"Error: Provenance receipt verification failed: {reason}")
        return 1

    bundle = load_frozen_reference_model()
    features_df = pd.read_csv(args.features_path)
    metrics = evaluate_frozen_model_on_cohort(bundle, features_df)

    # Shift against UAMS reference if UAMS processed table exists
    uams_path = ROOT / "data" / "processed" / "voice_features.csv"
    shift_summary = None
    if uams_path.is_file():
        uams_df = pd.read_csv(uams_path)
        shift_df = compute_feature_shift(uams_df, features_df)
        shift_csv = args.out_dir / f"{entry.domain_id}_feature_shift.csv"
        shift_df.to_csv(shift_csv, index=False)
        shift_summary = summarize_domain_shift(shift_df, acq_diffs).to_dict()

    eval_summary = {
        "domain_id": entry.domain_id,
        "status": "CANDIDATE_DOMAIN_EVALUATED_PENDING_REVIEW",
        "performance_metrics": {k: v.to_dict() for k, v in metrics.items()},
        "domain_shift_summary": shift_summary,
        "inference_eligible": False,
    }
    report_file = args.out_dir / f"{entry.domain_id}_evaluation_results.json"
    report_file.write_text(json.dumps(eval_summary, indent=2), encoding="utf-8")

    if args.json:
        print(json.dumps(eval_summary, indent=2))
    else:
        print(f"=== Domain Evaluation Completed: {entry.domain_id} ===")
        print(f"Status: {eval_summary['status']}")
        for k, v in metrics.items():
            print(f"- {k}: {v.point_estimate} (status: {v.status})")
        print(f"Report written to: {report_file}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
