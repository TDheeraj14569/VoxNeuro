"""Generate Milestone 4 review evidence files for VoxNeuro audit.

Produces:
  - review_evidence/m4_domain_registry.json
  - review_evidence/m4_domain_assessment.json
  - review_evidence/m4_domain_shift_summary.csv
  - review_evidence/m4_domain_shift_summary.json
  - review_evidence/m4_safety_gate_test_summary.json
  - review_evidence/m4_provenance_summary.json
  - review_evidence/m4_review_manifest.json
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import posixpath
import re
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Any

import pandas as pd

from voxneuro.features.schema import FEATURE_NAMES, schema_fingerprint
from voxneuro.features.tasks.schema import (
    connected_speech_schema_fingerprint,
    ddk_schema_fingerprint,
    v4_envelope_schema_fingerprint,
    vowel_space_schema_fingerprint,
)
from voxneuro.modeling import domains as domain_safety
from voxneuro.modeling.domain_assessment import (
    create_pending_framework_assessment_dossier,
)
from voxneuro.modeling.domain_evaluation import FROZEN_REFERENCE_MODEL_SHA256
from voxneuro.modeling.domain_registry import load_domain_registry
from voxneuro.modeling.domain_shift import compute_feature_shift
from voxneuro.provenance import project_code_fingerprint

ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = ROOT / "review_evidence"


def sanitize_target_path(target: str, repo_root: Path | str | None = None) -> str:
    """Sanitize a test target path cross-platform without leaking user directories or host paths."""
    target_str = str(target).strip()
    if not target_str:
        return ""

    if (
        target_str.startswith(r"\\\\")
        or target_str.startswith("//")
        or bool(re.match(r"^[\\/]{2}", target_str))
    ):
        clean_back = target_str.replace("/", "\\")
        pw = PureWindowsPath(clean_back)
        fn = pw.name or "test_file.py"
        return f"<temporary-dir>/{fn}"

    if target_str.startswith("~"):
        fn = posixpath.basename(target_str.replace("\\", "/").rstrip("/")) or "test_file.py"
        return f"<temporary-dir>/{fn}"

    has_win_drive = bool(re.match(r"^[A-Za-z]:[\\/]", target_str))
    is_posix_abs = target_str.startswith("/") and not target_str.startswith("//")

    root_val = repo_root or ROOT
    root_str = str(root_val)
    root_is_win = bool(re.match(r"^[A-Za-z]:[\\/]", root_str))
    root_is_posix = root_str.startswith("/") and not root_str.startswith("//")

    if not has_win_drive and not is_posix_abs:
        normalized_slash = target_str.replace("\\", "/")
        norm = posixpath.normpath(normalized_slash)
        if norm in (".", ""):
            return ""
        if norm.startswith("../") or norm == "..":
            fn = posixpath.basename(norm) or "test_file.py"
            return f"<temporary-dir>/{fn}"
        return norm

    if has_win_drive:
        if root_is_win:
            pw_target = PureWindowsPath(target_str)
            pw_root = PureWindowsPath(root_str)
            try:
                rel = pw_target.relative_to(pw_root)
                return rel.as_posix()
            except ValueError:
                return f"<temporary-dir>/{pw_target.name}"
        else:
            clean = re.sub(r"^[A-Za-z]:", "", target_str).replace("\\", "/")
            return f"<temporary-dir>/{posixpath.basename(clean.rstrip('/'))}"

    if is_posix_abs:
        if root_is_posix:
            pp_target = PurePosixPath(target_str)
            pp_root = PurePosixPath(root_str)
            try:
                rel = pp_target.relative_to(pp_root)
                return rel.as_posix()
            except ValueError:
                return f"<temporary-dir>/{pp_target.name}"
        else:
            return f"<temporary-dir>/{posixpath.basename(target_str.rstrip('/'))}"

    return f"<temporary-dir>/{posixpath.basename(target_str.replace('\\', '/').rstrip('/'))}"


def generate_domain_registry_evidence(out_dir: Path) -> Path:
    registry = load_domain_registry()
    data = registry.to_dict()
    data["registry_fingerprint"] = registry.fingerprint()
    target = out_dir / "m4_domain_registry.json"
    target.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return target


def generate_domain_assessment_evidence(out_dir: Path) -> Path:
    dossier = create_pending_framework_assessment_dossier()
    target = out_dir / "m4_domain_assessment.json"
    target.write_text(dossier.to_json(indent=2) + "\n", encoding="utf-8")
    return target


def generate_domain_shift_evidence(
    out_dir: Path,
    candidate_features_path: Path | None = None,
    candidate_domain_id: str | None = None,
    reference_features_path: Path | None = None,
) -> tuple[Path, Path]:
    """Generate domain-shift summary CSV and explicit pending/evaluation status JSON.

    Distinguishes:
    - Case A: Genuine external feature dataset exists with valid provenance and independence.
    - Case B: External feature data does not exist locally -> explicit pending status,
              empty CSV headers with NOT_EVALUATED status, and zero synthetic fallbacks.
    """
    ref_csv = reference_features_path or (ROOT / "data" / "processed" / "voice_features.csv")

    # Case A: Genuine external feature dataset exists
    if (
        candidate_features_path is not None
        and candidate_features_path.is_file()
        and candidate_domain_id is not None
        and ref_csv.is_file()
    ):
        ref_df = pd.read_csv(ref_csv)
        cand_df = pd.read_csv(candidate_features_path)

        if len(cand_df) > 0 and not cand_df.equals(ref_df):
            shift_df = compute_feature_shift(ref_df, cand_df, feature_names=FEATURE_NAMES)
            shift_df["evaluation_status"] = "EVALUATED"
            target_csv = out_dir / "m4_domain_shift_summary.csv"
            shift_df.to_csv(target_csv, index=False)

            ref_sha = hashlib.sha256(ref_csv.read_bytes()).hexdigest()
            cand_sha = hashlib.sha256(candidate_features_path.read_bytes()).hexdigest()
            status_data = {
                "milestone": "M4",
                "status": "DOMAIN_SHIFT_EVALUATED",
                "comparison_performed": True,
                "candidate_domain": candidate_domain_id,
                "reference_dataset_checksum": ref_sha,
                "candidate_dataset_checksum": cand_sha,
                "reference_participants": (
                    int(ref_df["participant_id"].nunique())
                    if "participant_id" in ref_df
                    else len(ref_df)
                ),
                "candidate_participants": (
                    int(cand_df["participant_id"].nunique())
                    if "participant_id" in cand_df
                    else len(cand_df)
                ),
                "features_evaluated": len(FEATURE_NAMES),
                "domain_shift_metrics": {
                    "features_significant_fdr": int(shift_df["shift_significant_fdr"].sum()),
                    "features_significant_bonferroni": int(
                        shift_df["shift_significant_bonferroni"].sum()
                    ),
                    "max_absolute_smd": float(shift_df["abs_smd"].max()),
                    "mean_absolute_smd": float(shift_df["abs_smd"].mean()),
                },
                "reason": (
                    "Empirical feature shift computed against verified external candidate dataset."
                ),
            }
            target_json = out_dir / "m4_domain_shift_summary.json"
            target_json.write_text(
                json.dumps(status_data, indent=2, sort_keys=True) + "\n", encoding="utf-8"
            )
            return target_csv, target_json

    # Case B: External feature data does not exist locally
    # Retain schema-consistent CSV headers only (0 data rows) - no zero-valued rows!
    empty_cols = [
        "feature",
        "ref_mean",
        "ref_sd",
        "ref_median",
        "ref_iqr",
        "cand_mean",
        "cand_sd",
        "cand_median",
        "cand_iqr",
        "smd_cohen_d",
        "abs_smd",
        "ks_statistic",
        "p_value_raw",
        "p_value_fdr",
        "p_value_bonferroni",
        "shift_significant_fdr",
        "shift_significant_bonferroni",
        "evaluation_status",
    ]
    empty_df = pd.DataFrame(columns=empty_cols)
    target_csv = out_dir / "m4_domain_shift_summary.csv"
    empty_df.to_csv(target_csv, index=False)

    status_data = {
        "milestone": "M4",
        "status": "DOMAIN_VALIDATION_PENDING",
        "comparison_performed": False,
        "reference_participants": None,
        "candidate_participants": None,
        "features_evaluated": 0,
        "domain_shift_metrics": None,
        "reason": "No eligible independent external feature dataset is available.",
    }
    target_json = out_dir / "m4_domain_shift_summary.json"
    target_json.write_text(
        json.dumps(status_data, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return target_csv, target_json


def generate_safety_gate_test_evidence(
    out_dir: Path,
    test_paths: list[str] | None = None,
) -> Path:
    """Run tests, capture JUnit XML, verify exit code, and record categorized results."""
    targets = test_paths or ["tests"]

    with tempfile.NamedTemporaryFile(suffix=".xml", delete=False) as tmp:
        xml_path = Path(tmp.name)

    try:
        cmd = [
            sys.executable,
            "-m",
            "pytest",
            *targets,
            f"--junitxml={xml_path}",
            "-q",
        ]
        proc = subprocess.run(
            cmd,
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            check=False,
        )

        test_cases: list[dict[str, Any]] = []
        total_tests = 0
        passed_tests = 0
        failed_tests = 0
        error_tests = 0
        skipped_tests = 0
        total_time = 0.0

        categories = {
            "m0_m3_regression_tests": {"total": 0, "passed": 0, "failed": 0},
            "m4_unit_tests": {"total": 0, "passed": 0, "failed": 0},
            "m4_integration_tests": {"total": 0, "passed": 0, "failed": 0},
            "private_dataset_dependent_tests": {"total": 0, "passed": 0, "failed": 0},
            "private_model_dependent_tests": {"total": 0, "passed": 0, "failed": 0},
            "streamlit_dependent_tests": {"total": 0, "passed": 0, "failed": 0},
        }

        if xml_path.is_file() and xml_path.stat().st_size > 0:
            tree = ET.parse(xml_path)
            root = tree.getroot()
            for suite in root.iter("testsuite"):
                total_time += float(suite.get("time", 0.0))
            for tc in root.iter("testcase"):
                total_tests += 1
                name = tc.get("name", "")
                classname = tc.get("classname", "")
                file_attr = tc.get("file", "")
                tc_time = float(tc.get("time", 0.0))

                failure = tc.find("failure")
                error = tc.find("error")
                skipped = tc.find("skipped")

                if failure is not None:
                    status = "failed"
                    failed_tests += 1
                elif error is not None:
                    status = "error"
                    error_tests += 1
                elif skipped is not None:
                    status = "skipped"
                    skipped_tests += 1
                else:
                    status = "passed"
                    passed_tests += 1

                if file_attr:
                    sanitized_file = sanitize_target_path(file_attr)
                else:
                    mod_path = classname.split(".Test")[0].replace(".", "/")
                    sanitized_file = f"{mod_path}.py"

                norm_key = (sanitized_file + " " + classname).replace("\\", "/").casefold()

                # Categorize test
                if (
                    "test_domain_" in norm_key
                    or "test_external_evaluation" in norm_key
                    or "test_inference_capture_context" in norm_key
                ):
                    cat_key = "m4_unit_tests"
                elif "test_m4_" in norm_key:
                    cat_key = "m4_integration_tests"
                elif "test_dataset" in norm_key or "test_audit_dataset" in norm_key:
                    cat_key = "private_dataset_dependent_tests"
                elif (
                    "test_verify_model" in norm_key
                    or "test_modeling" in norm_key
                    or "test_model_bundle" in norm_key
                ):
                    cat_key = "private_model_dependent_tests"
                elif "test_app" in norm_key or "test_multitask_app" in norm_key:
                    cat_key = "streamlit_dependent_tests"
                else:
                    cat_key = "m0_m3_regression_tests"

                categories[cat_key]["total"] += 1
                if status == "passed":
                    categories[cat_key]["passed"] += 1
                else:
                    categories[cat_key]["failed"] += 1

                test_cases.append(
                    {
                        "name": name,
                        "classname": classname,
                        "file": sanitized_file,
                        "category": cat_key,
                        "time_seconds": tc_time,
                        "status": status,
                    }
                )
    finally:
        if xml_path.is_file():
            try:
                xml_path.unlink()
            except OSError:
                pass

    summary = {
        "milestone": "M4",
        "generated_utc": datetime.now(UTC).isoformat(),
        "exit_code": proc.returncode,
        "fully_successful": (proc.returncode == 0 and failed_tests == 0 and error_tests == 0),
        "total_tests": total_tests,
        "passed_tests": passed_tests,
        "failed_tests": failed_tests,
        "error_tests": error_tests,
        "skipped_tests": skipped_tests,
        "blocked_tests": 0,
        "duration_seconds": round(total_time, 3),
        "python_version": sys.version,
        "platform": platform.platform(),
        "test_targets": targets,
        "categories": categories,
        "safety_invariants": {
            "allow_user_microphone_inference": False,
            "trusted_domain_validation_report_sha256_count": len(
                domain_safety.TRUSTED_DOMAIN_VALIDATION_REPORT_SHA256
            ),
            "approved_domains_count": len(load_domain_registry().approved_domains),
            "policy_status": "ENFORCED_FAIL_CLOSED",
        },
        "test_cases": test_cases,
    }

    target = out_dir / "m4_safety_gate_test_summary.json"
    target.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    return target


def generate_m4_provenance_evidence(out_dir: Path) -> Path:
    registry = load_domain_registry()
    dossier = create_pending_framework_assessment_dossier()

    summary = {
        "milestone": "M4",
        "generated_utc": datetime.now(UTC).isoformat(),
        "python_version": sys.version,
        "platform": platform.platform(),
        "project_code_fingerprint": project_code_fingerprint(),
        "canonical_v3_schema_fingerprint": schema_fingerprint(),
        "ddk_v1_schema_fingerprint": ddk_schema_fingerprint(),
        "connected_speech_v1_schema_fingerprint": connected_speech_schema_fingerprint(),
        "vowel_space_v1_schema_fingerprint": vowel_space_schema_fingerprint(),
        "v4_envelope_schema_fingerprint": v4_envelope_schema_fingerprint(),
        "domain_registry_fingerprint": registry.fingerprint(),
        "domain_assessment_dossier_fingerprint": dossier.fingerprint(),
        "reference_model_artifact_sha256": FROZEN_REFERENCE_MODEL_SHA256,
        "domain_compatibility_status": "FRAMEWORK_VERIFIED_DOMAIN_VALIDATION_PENDING",
        "trusted_domain_allowlist_count": len(
            domain_safety.TRUSTED_DOMAIN_VALIDATION_REPORT_SHA256
        ),
        "approved_domains": list(registry.approved_domains),
        "microphone_inference_policy": "allow_user_microphone_inference: false (locked)",
    }
    target = out_dir / "m4_provenance_summary.json"
    target.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return target


def generate_review_manifest(out_dir: Path, artifacts: list[Path]) -> Path:
    records: list[dict[str, Any]] = []
    for art in artifacts:
        rel = art.relative_to(ROOT).as_posix()
        data = art.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        records.append(
            {
                "path": rel,
                "size_bytes": len(data),
                "sha256": digest,
            }
        )

    manifest = {
        "manifest_version": "1.0.0",
        "milestone": "M4",
        "generated_utc": datetime.now(UTC).isoformat(),
        "artifacts": sorted(records, key=lambda x: x["path"]),
    }
    target = out_dir / "m4_review_manifest.json"
    target.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return target


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Generate M4 review evidence.")
    parser.add_argument(
        "--test-paths",
        nargs="*",
        default=None,
        help="Specific test directories or files to run for test evidence",
    )
    args = parser.parse_args(argv)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    print("Generating M4 review evidence artifacts...")

    reg_p = generate_domain_registry_evidence(OUTPUT_DIR)
    print(f"Generated: {reg_p.relative_to(ROOT)}")

    dos_p = generate_domain_assessment_evidence(OUTPUT_DIR)
    print(f"Generated: {dos_p.relative_to(ROOT)}")

    shift_csv_p, shift_json_p = generate_domain_shift_evidence(OUTPUT_DIR)
    print(f"Generated: {shift_csv_p.relative_to(ROOT)}")
    print(f"Generated: {shift_json_p.relative_to(ROOT)}")

    safety_p = generate_safety_gate_test_evidence(OUTPUT_DIR, test_paths=args.test_paths)
    print(f"Generated: {safety_p.relative_to(ROOT)}")

    prov_p = generate_m4_provenance_evidence(OUTPUT_DIR)
    print(f"Generated: {prov_p.relative_to(ROOT)}")

    manifest_p = generate_review_manifest(
        OUTPUT_DIR, [reg_p, dos_p, shift_csv_p, shift_json_p, safety_p, prov_p]
    )
    print(f"Generated: {manifest_p.relative_to(ROOT)}")

    print("All M4 review evidence successfully generated.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
