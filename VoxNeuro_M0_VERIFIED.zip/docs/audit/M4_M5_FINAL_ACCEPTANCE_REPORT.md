# VoxNeuro M4/M5 Final Acceptance Report

**Report Scope:** Milestone 4 & Milestone 5 Final Acceptance Repair and Release Verification  
**Baseline Input Archive:** `VoxNeuro_M5_VERIFIED(2).zip` (`SHA-256: 19b49228fccb33f52d89ddacb3dc77fad00f5597e5895ce02f70ceaafbab8a61`)  
**Target Deliverable:** `VoxNeuro_M5_VERIFIED.zip` + `VoxNeuro_M5_VERIFIED.zip.sha256`  
**Project Code Fingerprint:** `72fc3f555729791e95e556627621be595af68d2fe1dada09cb4f340e5c21920e`  
**Execution Environment:** Python 3.12.16, `uv` (frozen lockfile)  

---

## 1. Evidence Classification Matrix

| Capability / Claim | Status | Basis & Scope |
|---|---|---|
| Source-roster-bound `IndependenceAttestation` (no unsafe defaults, file-byte SHA-256 re-verification, normalization/overlap recomputation, reviewer & source authority checks) | **Implemented, Unit-tested** | `src/voxneuro/modeling/domain_evaluation.py`; verified with synthetic/controlled rosters in `test_m4_provenance_and_roster_binding.py` and `test_external_evaluation.py`. |
| Authoritative dataset DUA verification (`DatasetAccessRecord` / SQLite `dataset_access`, `dua_document_fingerprint`, task/operation scoping) & `MODEL_ARTIFACT_NOT_VERIFIED` check | **Implemented, Unit-tested** | `src/voxneuro/modeling/domain_evaluation.py`, `scripts/evaluate_external_domain.py`, migration `004_dataset_access_dua_fingerprint.sql`. |
| Consent operation/scope mapping (`OPERATION_AUTHORIZATION_MAP`) and centralized preflight in `record_task_recording()` | **Implemented, Unit-tested, Integration-tested** | `src/voxneuro/study/session.py`; enforced across M5 unit/integration tests and direct-call bypass checks. |
| M5 consent default evidence (`derived_features_retention_default: false`) derived from `ConsentRecord` + SQLite `PRAGMA table_info(consents)` | **Implemented, Unit-tested, Runtime-verified** | `scripts/generate_m5_review_evidence.py`, verified in generated `review_evidence/m5_consent_governance_summary.json`. |
| Dataset access release evidence honesty (`RUNTIME_DATASET_AUTHORIZATION_NOT_INCLUDED_IN_RELEASE`, `registered_datasets: []`) | **Implemented, Unit-tested, Runtime-verified** | Hardcoded UAMS/UCI `APPROVED` claims removed; runtime DB queried only if configured. |
| Release evidence path sanitization (`uv run pytest -q --junitxml=<temporary-report-path>`) | **Implemented, Unit-tested, Runtime-verified** | Zero workstation paths in `review_evidence/` enforced by unit tests and `scripts/build_ai_review_bundle.py`. |
| Automated M0–M5 local test suite (incl. UAMS/UCI private data & reference model) | **Runtime-verified** | 566 passed, 0 failed, 0 skipped (60.24s in M5 run; 59.476s in M4 run). |
| Clean-room ZIP verification (`ruff`, `pytest`, `verify_project.py`, bypass assertions) | **Pending Release Build Execution (Step 7)** | Run against extracted `VoxNeuro_M5_VERIFIED.zip` immediately after documentation & bundle build. |
| Independent external recording-domain clinical validation (`NeuroVoz`, `PC-GITA`, `Italian IPVS`) | **Blocked** | Licensed external audio/features and executed external DUAs are absent from the local workspace (`FRAMEWORK_VERIFIED_DOMAIN_VALIDATION_PENDING`). |
| Live user microphone diagnostic inference | **Blocked (Intentionally Disabled / N/A)** | Locked fail-closed (`allow_user_microphone_inference: false`, `approved_domains: []`, `TRUSTED_DOMAIN_VALIDATION_REPORT_SHA256 = frozenset()`). |

---

## 2. Fail-Closed Safety Invariants

All mandatory safety invariants remain enforced:
- `configs/model_config.yaml`: `allow_user_microphone_inference: false`, `clinical_diagnostic_use: false`
- `src/voxneuro/modeling/domains.py`: `TRUSTED_DOMAIN_VALIDATION_REPORT_SHA256 = frozenset()`, `external_domain_validation_status = "DOMAIN_VALIDATION_PENDING"`
- `configs/recording_domain_registry.yaml`: `approved_domains: []`, every candidate domain has `inference_eligible: false`
- `ConsentRecord` and migrated SQLite `consents`: `permission_to_retain_derived_features = False` (`0`), `permission_to_retain_audio = False` (`0`)
- No M6 modules, migrations, schemas, tests, documentation, or release hooks exist anywhere in the repository.
