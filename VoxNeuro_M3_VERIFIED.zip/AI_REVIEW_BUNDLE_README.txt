VoxNeuro AI review bundle (M3)
========================

This ZIP contains the complete compact source package plus aggregate model-evaluation evidence.
The hashes below let a reviewer check the exact evidence files.

Scope and privacy
-----------------
- `review_evidence/` contains cohort summaries, fold metrics, and provenance receipts.
- Audio, participant-level feature/prediction rows, and model binaries are excluded.
- The source includes a reviewed policy with pseudonymous UAMS IDs for reproducibility.
  The supplemental dataset audit HTML contains aggregate counts only.
- The bundled feature-extraction receipt replaces its excluded-ID list with a count.
- UAMS results are internal estimates from a small, age-confounded cohort. They are not
  external or clinical validation. The app does not classify new microphone recordings.
- UCI is a separate pre-extracted feature benchmark; it does not validate raw-WAV processing.
- Exact evaluation settings and limits are in `configs/model_config.yaml`, `docs/methodology/`,
  and `docs/reports/MODEL_CARD.md`.

Evidence files
--------------
- `m2_age_subgroup_summary.csv` — SHA-256 `bc11d3e8bacd8fcce9e653279f71a789a5c0bf0923fde5c76055a83c5b9f40e2`
- `m2_analysis_receipt.json` — SHA-256 `024dbc99928848af3c39281fbc92d354c7f5eadf2cbfd25e922d030fd577cec8`
- `m2_attrition_analysis.html` — SHA-256 `119f8a32bb57494c735e2d394e1dce0a773a4beae8551af272868eeb7d00123f`
- `m2_attrition_summary.json` — SHA-256 `b09f086844fa5da44b25090c31f72283406c3cbe1521b390b159f6963298fe6f`
- `m2_bias_audit.html` — SHA-256 `b3a68edf4ad74c8ef2be951d121cbf3fe4dab9b0e24c5bedaa9ac03e0e82041f`
- `m2_comparator_metrics.csv` — SHA-256 `1e46600194f99f0834f3f53476ffe4096c02980e5b012e9db6c5fa89a495d087`
- `m2_demographic_audit.html` — SHA-256 `b71c0cea11abde166f5648dce6f7a30cbd6349d2613eb6f021958c320e1b65bd`
- `m2_demographic_summary.json` — SHA-256 `86bb4531282d8cd519fdbb9afab24f45104db0d0b469aef21bd19dcffe484ebf`
- `m2_feature_fdr_summary.csv` — SHA-256 `fc079c23860ca80f55bea5ea4a7fe3c2b04f04b1b4a1c5fcf8a7c367c6c437b6`
- `m2_matching_balance.html` — SHA-256 `15dd424dd05ecd3d9e629621dc2c5e372a7785bbe6c3218dc2ef4d72d55730fa`
- `m2_matching_sensitivity.csv` — SHA-256 `f5933d686f43abda0ce7a9b4e1019f07f8bab90931afb25b79628c27b4f39830`
- `m2_model_comparison.html` — SHA-256 `e7a86a5655240e81f9bb36acab54916a742a84c4137b55e25622cac66b2d6d3f`
- `m2_paired_incremental_voice.csv` — SHA-256 `6b1fdecf9ea64519f7f6a97924aa78a6761d81e65f52d0cf7689352f0169c762`
- `m2_sex_subgroup_summary.csv` — SHA-256 `53e4df97e41b897d7bc5a2e7b796e8f25d94a1ef645101b989c149f7129b4f4f`
- `m3_implementation_test_summary.json` — SHA-256 `eb19801f720d889767d4e13631932a27b4394c1676afb5a0da5cfd2c8b2f9b7e`
- `m3_provenance_summary.json` — SHA-256 `65931f670a6f09ca0b34dabe0abc94e7a7472d16eaa953906744a6b3ea872f0c`
- `m3_synthetic_fixture_verification.json` — SHA-256 `1ee464d4307a10780e4a61abafe5af7902a1b6e4084a020e9e6d32a5a55ae099`
- `m3_task_feature_contract.csv` — SHA-256 `3dc96d65e1fcef1706f366814edb939174bb215b9bebdb3204e2c9d7d471715d`
- `m3_task_schema_registry.json` — SHA-256 `2681742185d49f5a19dac0bb9b9504f0178a7bd1f1c025d474a3efb577eb129d`
- `uams_dataset_audit.html` — SHA-256 `ce9a1c6de68f0ad419edbe275402d4128e7f23aa9e83e0715915bb7c59f8e747`
- `uams_feature_extraction_receipt.json` — SHA-256 `c07e523032e92c0301a6e393efc476a2de278c520892031f9e2dc420d400356c`
- `uams_grouped_evaluation_receipt.json` — SHA-256 `276de2d698b95535cf27e1e3444c2f7a3da52c55b40c3b5a41c5f16dab448431`
- `uams_nested_evaluation.html` — SHA-256 `636fceb96107db8ce3957673f4774bef52fc50f7978f150f627ebbf758829249`
- `uams_nested_evaluation_receipt.json` — SHA-256 `979affe5ae11c614a60c3cf48f956f6705537e43dc05855ccca32911285fb5dc`
- `uams_nested_fold_metrics.csv` — SHA-256 `eb0c9c346e4447ed042d47cccdbed844c10251afcc7945b73da3096bf8321ecc`
- `uams_nested_summary.csv` — SHA-256 `bc012fb78116c8dd666869a0fff6d371580a66664d42036b05cd69f6da26b75d`
- `uci_duplicate_sensitivity.csv` — SHA-256 `795ef6524fc91f058b2d62a5882d491e3ec31fc6c39db6501f0a3cf4b37aab62`
- `uci_evaluation_receipt.json` — SHA-256 `f26632e3e76ebc544a19130f4085a15c8a56b7577e8aa176273838a739ff9003`
- `uci_grouped_fold_metrics.csv` — SHA-256 `9f2ce6abdce5fb3a3c314ff6d5e6168e671d7a9302087435ad89e05c3497496a`

The source inventory excludes this README and `review_evidence/`: they are review
attachments, not project source files.
