VoxNeuro AI review bundle
========================

This ZIP contains the complete compact source package plus aggregate model-evaluation evidence.
The hashes below let a reviewer check the exact evidence files.

Scope and privacy
-----------------
- `review_evidence/` contains cohort summaries, fold metrics, and provenance receipts.
- Audio, participant-level feature/prediction rows, and model binaries are excluded.
- The source includes a reviewed policy with pseudonymous UAMS IDs for reproducibility.
  The supplemental dataset audit HTML contains aggregate counts only.
- The bundled feature-extraction receipt replaces its excluded-ID list with a count.
- UAMS results are internal estimates from a small, age-confounded cohort. They are not
  external or clinical validation. The app does not classify new microphone recordings.
- UCI is a separate pre-extracted feature benchmark; it does not validate raw-WAV processing.
- Exact evaluation settings and limits are in `configs/model_config.yaml`, `docs/methodology/`,
  and `docs/reports/MODEL_CARD.md`.

Evidence files
--------------
- `uams_dataset_audit.html` — SHA-256 `ce9a1c6de68f0ad419edbe275402d4128e7f23aa9e83e0715915bb7c59f8e747`
- `uams_feature_extraction_receipt.json` — SHA-256 `71b7f0ce4621c51c3eaafa503d187ce777231accff112b639ad4818a06a276b6`
- `uams_grouped_evaluation_receipt.json` — SHA-256 `d1130ee06f998fcbfdc946ad4f2373d4b7c05c93b2444fae0b6a3f9dad48676f`
- `uams_nested_evaluation.html` — SHA-256 `3410889a18fc6c858fd2b2976cf2bd31b332ccaf70620caa76c0788043ab5799`
- `uams_nested_evaluation_receipt.json` — SHA-256 `e679371d89ba21ec427382f3f51ec3d37899d1363ebdf1f60f9a7002f01be0c6`
- `uams_nested_fold_metrics.csv` — SHA-256 `eb0c9c346e4447ed042d47cccdbed844c10251afcc7945b73da3096bf8321ecc`
- `uams_nested_summary.csv` — SHA-256 `bc012fb78116c8dd666869a0fff6d371580a66664d42036b05cd69f6da26b75d`
- `uci_duplicate_sensitivity.csv` — SHA-256 `795ef6524fc91f058b2d62a5882d491e3ec31fc6c39db6501f0a3cf4b37aab62`
- `uci_evaluation_receipt.json` — SHA-256 `9c1c6bcbd317a9959339fec419a8a5db6ba7c094bc49bcf83cfd521f19a88e24`
- `uci_grouped_fold_metrics.csv` — SHA-256 `9f2ce6abdce5fb3a3c314ff6d5e6168e671d7a9302087435ad89e05c3497496a`

The source inventory excludes this README and `review_evidence/`: they are review
attachments, not project source files.
