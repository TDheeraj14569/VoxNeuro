# Reproducibility record

## Environment used for the latest model run

- Windows 11, CPython 3.12.16, uv 0.13.7.
- Locked dependencies include NumPy 2.5.4, pandas 3.1.1, SciPy 1.18.1, scikit-learn 1.9.1, Librosa 0.11.0, praat-parselmouth 0.4.7, SoundFile 0.14.0, Streamlit 1.66.1, and joblib 1.6.0.
- The project lock is in uv.lock and requirements-lock.txt. These results were generated in the workspace with the locked environment; bit-for-bit identity across hardware/library versions is not asserted.

## UAMS nested run provenance

- Source fingerprint: b30f309161eb1804e528d7a4c02f3424e41af138fa39f1684b78c68afa7f68d1.
- Feature schema: voxneuro.voice.v3; schema fingerprint a7e3374210617f1e94897a219bf373be4aaa73a4fa5ec1d9581947cce2ab3e9f.
- Feature configuration fingerprint: 190e79c16b8a92f6c7fa8de47956531ade096c43e5f3974d9ce9b5d88b74b5f9.
- Preprocessing configuration fingerprint: 8cd060e419204da2beb98454d8511631e3f00e87971b17b3ea732d39e606189d.
- Manifest SHA-256: f4c5c0325ad6c2ce629dead6f91fa1ab5f9888b45bd4c19d96786f2853206e92.
- Extracted feature-table SHA-256: ec406fe8f1630a1ccadae3f547af252cc2fa460cddeb06a516b4f21bd7b4bc4c.
- Outer/inner splits: 5/3; repeats: seeds 2026, 2027, 2028; 1,000 participant bootstrap iterations for the primary repeat.
- Selection metric: inner-fold balanced accuracy. No outer-fold threshold selection; probability calibration was not fitted.
- Current results and artifact checksums: data/processed/nested_uams_evaluation_receipt.json. The human-readable report is artifacts/reports/model_evaluation/uams_nested.html.
- Nested metrics CSV SHA-256: e1d714a26c4fae4283dc3550047a64b94c9748a26c802d9f3aeaaf3e04f58e9e.
- Participant-level out-of-fold predictions SHA-256: 8450d079ab3769e3f8e7a275148b41fb53a6f0a625f87326f0ad0336284ffa0e.
- Fold metrics CSV SHA-256: eb0c9c346e4447ed042d47cccdbed844c10251afcc7945b73da3096bf8321ecc.
- Summary CSV SHA-256: bc012fb78116c8dd666869a0fff6d371580a66664d42036b05cd69f6da26b75d.

## Reproduction commands

Run from the repository root with the checked-out UAMS and UCI source data present:

    uv sync --all-extras --locked
    uv run python scripts/audit_dataset.py
    uv run python scripts/extract_features.py --allow-reviewed-exclusions
    uv run python scripts/evaluate_model.py --dataset uams
    uv run python scripts/evaluate_nested_models.py --dataset uams
    uv run python scripts/evaluate_model.py --dataset uci
    uv run python scripts/train_model.py --dataset uams
    uv run python scripts/verify_model.py

The extraction option accepts only the three reviewed PD clipping exclusions listed in project configuration. Without those exact exclusions, partial extraction is rejected. Training is blocked when the extraction/evaluation receipts do not match current files, settings, schema, and code.

The trained artifact is written to artifacts/models/uams_logistic_research.joblib with a SHA-256 sidecar. It is an offline research reference and is not enabled for user microphone inference. The app abstains because input-domain compatibility is unverified.

## WAV smoke report

A real WAV from the UAMS development cohort was processed as a software smoke test and written to artifacts/reports/individual/uams_training_recording_smoke_test.html. It verifies decoding, validation, Core39 feature extraction, and HTML report generation only. The recording belongs to the development cohort, so this is not independent prediction or validation.

The source-audit ZIP excludes all data, trained models, and generated evaluation outputs; obtain the datasets separately under their stated terms before reproducing these results.
