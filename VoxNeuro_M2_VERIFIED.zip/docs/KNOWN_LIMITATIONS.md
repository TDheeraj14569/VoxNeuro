# Known limitations and blockers

## Clinical and scientific

- **Non-Diagnostic Nature:** VoxNeuro is an academic research prototype. It is not a disease detector, diagnostic device, screening instrument, or clinical decision-support product. It returns audio quality and technical acoustic measurements only.
- **Unvalidated Need Statement:** The clinical need remains a research hypothesis. No stakeholder interview, observation, clinician endorsement, or patient feedback is claimed.
- **Severe Demographic Confounding (M2 Finding):** The UAMS cohort exhibits an extreme age disparity between Healthy Controls ($47.73 \pm 14.33$ years) and Parkinson's Disease participants ($67.04 \pm 8.98$ years; SMD $= -1.61$, $p = 1.75 \times 10^{-8}$). An age-only logistic classifier achieves **83.89%** balanced accuracy, exceeding all tested voice-only models (best linear SVM: 70.54%, logistic: 73.88%).
- **Absence of Incremental Voice Diagnostic Power (M2 Finding):** In paired out-of-fold testing, adding 39 acoustic features to demographic age reduces balanced accuracy by **-6.81%** ($77.08\%$ vs $83.89\%$, McNemar exact $p = 0.2632$). Adding voice to age and sex combined reduces balanced accuracy by **-7.63%** ($76.18\%$ vs $83.81\%$, McNemar exact $p = 0.2101$). Acoustic voice analysis provides zero statistically significant incremental diagnostic power beyond basic demographic variables.
- **Sample Size Exhaustion on Caliper Matching (M2 Finding):** Constructing a defensible age- and sex-matched subcohort with standard epidemiological calipers ($0.2$ pooled SD $= 2.44$ years) retains only **5 pairs (10 participants)** &mdash; an $87.2\%$ participant attrition rate. Consequently, cross-validation modeling on a matched cohort is formally **NOT ESTIMABLE** due to minimal class partition constraints.
- **Class-Dependent Recording Attrition:** Quality exclusions (excessive acoustic clipping $>0.5\%$ samples) occurred exclusively in the Parkinson's cohort ($3/40$ PD excluded [$7.5\%$] vs $0/41$ HC [$0.0\%$]; Fisher exact $p = 0.1158$). This reflects transmission gain calibration difficulties in dysphonic patients and introduces potential class-specific selection bias.
- **Unverified Device Compatibility:** UAMS is telephone-collected; laptop/smartphone acquisition equivalence has not been established. Matching feature names or resampling rates do not prove domain compatibility.
- **Benchmark Separation:** UCI #470 is a separate pre-extracted feature-table benchmark. It is not external validation of the raw-audio extractor.
- **Limited Task Scope:** The task is a sustained vowel (/a/); connected speech, language, articulation, intelligibility, prosody, longitudinal progression, and representative primary-care populations are untested.
- **Prospective Protocol Mandate:** There is no currently available independent external validation cohort. Phase 8 establishes a formal prospective protocol (`docs/clinical_validation/M2_EXTERNAL_COHORT_PROTOCOL.md`) requiring $N=240$ participants ($1:1$ frequency matched by age band and sex) to definitively resolve whether voice contains disease-specific signal under standardized booth recording conditions.

## Software and environment

- Python 3.12 is required by `pyproject.toml`; dependencies are locked. The source ZIP omits datasets and model/evaluation artifacts, so data-specific scripts require separately obtained licensed local data.
- The browser microphone control was rendered and tested in Streamlit AppTest, but real browser/OS permission and physical microphone capture have not been verified. Microphone prediction is locked by safety configuration (`allow_user_microphone_inference: false`).
- UCI archive extraction relies on Windows `tar` support for RAR. An installation without that support must use a suitable extraction environment.
- The model checksum detects byte changes but does not authenticate the signer or make arbitrary joblib files safe.
- `.git` and trained artifacts are local only; there is no remote, release tag, or signed release in this package.

## Data and evidence

- The ZIP alone cannot reproduce reported cohort metrics because local datasets and generated outputs are omitted.
- The source cohort's capture hardware/channel details, task adherence, and clinical context are incompletely characterized.
- A technical signal-quality pass does not imply normal health, and extraction failure does not imply disease.
