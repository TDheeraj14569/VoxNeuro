"""Quick source-tree and import verification independent of external datasets."""

from __future__ import annotations

import importlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

REQUIRED = [
    "app.py",
    "pyproject.toml",
    "requirements-lock.txt",
    "uv.lock",
    "README.md",
    ".streamlit/config.toml",
    "src/voxneuro/audio/io.py",
    "src/voxneuro/features/extractor.py",
    "src/voxneuro/dataset/uci.py",
    "src/voxneuro/modeling/evaluation.py",
]
MODULES = [
    "voxneuro.audio.io",
    "voxneuro.audio.validation",
    "voxneuro.audio.preprocessing",
    "voxneuro.features.extractor",
    "voxneuro.dataset.audit",
    "voxneuro.dataset.uci",
    "voxneuro.modeling.evaluation",
    "voxneuro.modeling.model_bundle",
    "voxneuro.modeling.prediction",
    "voxneuro.modeling.dataset_readiness",
    "voxneuro.modeling.m6_experiment",
    "voxneuro.modeling.model_registry",
    "voxneuro.modeling.prediction_service",
    "voxneuro.study.auth",
    "voxneuro.ui.theme",
    "voxneuro.provenance",
    "voxneuro.reporting.report",
]


def main() -> int:
    missing = [path for path in REQUIRED if not (ROOT / path).is_file()]
    for path in missing:
        print(f"FAIL missing {path}")
    if missing:
        return 1
    for name in MODULES:
        importlib.import_module(name)
        print(f"PASS import {name}")
    print(f"PASS required files ({len(REQUIRED)})")
    prov_mod = importlib.import_module("voxneuro.provenance")
    prov = prov_mod.release_provenance()
    print(
        f"PASS release provenance (pipeline={prov['model_pipeline_fingerprint'][:8]}..., "
        f"frontend={prov['frontend_fingerprint'][:8]}...)"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
